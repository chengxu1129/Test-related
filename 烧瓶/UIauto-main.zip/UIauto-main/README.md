# UIauto
UI自动化测试框架

app           对airtest进行二次封装                         是
common	      这个包中存放的是常见的通用的类，如读取配置文件	是

config	      配置文件目录	                            是

logs	      日志目录	

page	      对selenium的方放进行深度的封装	            是

page_element  页面元素存放目录	

page_object	  页面对象POM设计模式	              是
resource      存放模板图片及配置图片的文件        是

TestCase	  所有的测试用例集	                                    是

utils	      工具类	                                            是

script	      脚本文件	

conftest.py	  pytest胶水文件	

pytest.ini	  pytest配置文件


