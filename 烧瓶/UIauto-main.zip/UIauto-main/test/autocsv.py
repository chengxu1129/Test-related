#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:autocsv.py
@time:2021/11/01
"""
import csv

produces=[]
tenants1=[]
tenants2=[]

#读取csv文件
def readCsv(filename:str):
    with open(filename) as f:
        f_csv=csv.reader(f)
        headers=next(f_csv)
        for row in f_csv:
            if row[0]=="产品":
                produces.append(row)
            if row[0]=="租户1":
                tenants1.append(row)
            elif row[0]=="租户2":
                tenants2.append(row)
#给文件增加名字
def addName(arr):
    for i in arr:
        i[6]=i[1]+i[2]+i[3]

#给租户添加临时路径 每增加一个租户 列表增加2个
def tenantAddProduce(tenant:list,fi):
    way=[]
    way.append(tenant[1][:2]+tenant[2][:2]+tenant[3][:2])
    if int(tenant[3][1])>1:
        way.append(tenant[1]+tenant[2]+fi[3])#第三个数是租户第一个数值的C1
        way.append(tenant[1][:2]+tenant[2][:2]+fi[3][:2])
    if int(tenant[2][1])>1:
        way.append(tenant[1]+fi[2]+fi[3])
        way.append(tenant[1][:2]+fi[2][:2]+fi[3][:2])
    if int(tenant[1][1])>1:
        way.append(fi[1]+fi[2]+fi[3])
        way.append(fi[1][:2]+fi[2][:2]+fi[3][:2])
    return way

#把路径添加到数组中
def addInUsers(users):
    for i in users:
        path=tenantAddProduce(i,users[0])
        i[7]=path

def addAllUsers():
    addInUsers(produces)
    addInUsers(tenants1)
    addInUsers(tenants2)

#给所有的用户添加相对路径
def addRelationPath():
    addName(produces)
    addName(tenants1)
    addName(tenants2)


def toge():
    return  dict(zip([i[6] for i in produces]+[i[6] for i in tenants1]+[i[6] for i in tenants2], produces+tenants1+tenants2))
#根据路径找到元数据
def addProData(users,dic):
    for i in users:
        if i[4]=='是':
            i[8]=i[6]
        elif i[4]=='否':
            for j in i[7]:
                if dic[j][4]=='是':
                    i[8]=j
                    break

def addAllProData(dic):
    addProData(produces,dic)
    addProData(tenants1,dic)
    addProData(tenants2,dic)
def writeOne(writer,users):
    for i in users:
        writer.writerow(i)

#写入csv
def writeCsv():
    with open('2.csv',mode='w') as f:
        writer=csv.writer(f)
        writer.writerow(['场景','标签','标签','标签','是否存在个性化','对应的元数据','name','path','fin'])
        writeOne(writer,produces)
        writeOne(writer, tenants1)
        writeOne(writer,tenants2)

def show(users):
    for i in users:
        print(i)

# class F:
#     test = 1
#     flag='111'
#     def __init__(self,a,b,c,flag):
#         self.a=a
#         self.b=b
#         self.c=c
#         self.flag=flag
#         self.name=a+b+c
#
# class S1(F):
#     test=2
#     def __init__(self, a, b, c, flag):
#         # if self.flag=='否':
#         #     if
#         #     return super().flag
#         super().__init__(a, b, c, flag)
#
#     def findFlag(self,flag):
#         if flag=='是':
#             return self.name
#         else:
#         # return self.findFlag(super(S1, self).flag)
#             t=super(S1, self).__init__('A1\'','B1','C1','否')
#             return t




if __name__ == '__main__':
    pass
    readCsv('1.csv')
    addAllUsers()
    addRelationPath()
    d = toge()
    addAllProData(d)
    writeCsv()
    # show(produces)
    # show(tenants1)
    # show(tenants2)
























'''
{'产品':{
    'A1':{
        'B1':{
            'C1':{'是','A1B1C1',''},
            'C2':'是',
            'C3':'否'
        },
        'B2':{
            'C1':'是',
            'C2':'是',
            'C3':'否'
        },
    },
    'A2':{
            'B1':{
                'C1':'是',
                'C2':'是',
                'C3':'否'
            },
            'B2':{
                'C1':'是',
                'C2':'是',
                'C3':'否'
            },
        },
}
}
'''
