#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:pytest_test.py
@time:2021/11/19
"""

'''
    函数式
'''
import pytest


def setup_function():
    print('每个用例开始前会执行')

def teardown_function():
    print('每个用例结束后会执行')


def test_one():
    print('第一条用例')
    x='this'
    assert 'h' in x

def test_two():
    print('第二条用例')
    x='this'
    assert 'h' in x


if __name__ == '__main__':
    pass
