#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:teardown练习.py
@time:2021/11/22
"""


import pytest


@pytest.fixture(scope='module',autouse=True)
def open():
    print('打开浏览器')
    yield
    print('关闭浏览器')

def test_s1():
    print('执行用例1')

def test_s2():
    print('执行用例2')

def test_s3():
    print('执行用例3')





# arr=(i for i in range(10))
# for i in arr:
#     print(i)


def demo():
    res1=yield 1
    print(res1)
    res2 = yield 2
    print(2)






if __name__ == '__main__':
    #pytest.main(['-s','teardown练习.py'])
    t1=demo()
    print(next(t1))
    print(t1.send('回传'))
