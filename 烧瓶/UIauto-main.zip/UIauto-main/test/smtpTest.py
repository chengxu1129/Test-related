#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:smtpTest.py
@time:2021/10/19
"""

import smtplib
from email.mime.text import MIMEText
from email.header import Header


def sendEmail():
    send = 'smtp.exmail.qq.com'

    user = 'chengx04@mingyuanyun.com'
    password = '75264186Gui'

    sender = 'chengx04@mingyuanyun.com'
    rece = 'chengx04@mingyuanyun.com'

    subject = 'Test'
    msg = MIMEText('<html<h1>你好!</h1></html>', 'html', 'utf-8')
    msg['Subject'] = Header(subject, 'utf-8')

    smtp = smtplib.SMTP()
    smtp.connect(send)
    smtp.login(user, password)
    smtp.sendmail(sender, rece, msg.as_string())
    smtp.quit()


#练习算法
#冒泡
def maopao(arr):
    n=len(arr)
    for i in range(n):
        for j in range(n-1-i):
            if arr[j]>arr[j+1]:
                arr[j],arr[j+1]=arr[j+1],arr[j]

#选择
def xuanze(arr):
    n=len(arr)
    for i in range(n):
        min=i
        for j in range(i+1,n):
            if arr[min]>arr[j]:
                min=j
        arr[i],arr[min]=arr[min],arr[i]


class BinaryTree:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

    def get(self):
        return self.data

    def getLeft(self):
        return self.left

    def getRight(self):
        return self.right

    def setLeft(self, node):
        self.left = node

    def setRight(self, node):
        self.right = node


binaryTree = BinaryTree(0)
binaryTree.setLeft(BinaryTree(1))
binaryTree.setRight(BinaryTree(2))
binaryTree.getLeft().setLeft(BinaryTree(3))
binaryTree.getLeft().setRight(BinaryTree(4))
binaryTree.getRight().setLeft(BinaryTree(5))
binaryTree.getRight().setRight(BinaryTree(6))


def preorderTraversal(now, result=[]):
    if now == None:
        return result
    result.append(now.data)
    preorderTraversal(now.left, result)
    preorderTraversal(now.right, result)
    return result

if __name__ == '__main__':
    arr=[1,134,1,41,41,1]
    #maopao(arr)
    xuanze(arr)
    print(arr)
    print(preorderTraversal(binaryTree))






