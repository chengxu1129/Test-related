#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:classTest.py
@time:2021/10/22
"""

class Temo:
    name='ada'
    def __init__(self):
        self.arr={}
    def __setitem__(self, key, value):
        self.arr[key]=value
    def __getitem__(self, item):
        return self.arr[item]

    @staticmethod
    def eat():
        print(Temo.name)




if __name__ == '__main__':
    t1=Temo()
    t1['id']=1
    print(t1['id'])
    t1.eat()
    print(Temo.__dict__)