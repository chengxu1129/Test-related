#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:fixture练习.py
@time:2021/11/22
"""

import pytest

#不带参数时默认scope="function"
@pytest.fixture()
def login():
    print('先进行登录')

def test_s1(login):
    print('需要登录,执行用例1')

def test_s2():
    print('不需要登录,执行用例2')

def test_s3(login):
    print('需要登录,执行用例3')

















if __name__ == '__main__':
    pytest.main(['-s','fixture练习.py'])
