#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:webpage.py
@time:2021/11/04
封装selenium基类
"""

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException

from config.conf import cm
from utils.times import sleep
from utils.logger import log
from selenium import webdriver
from common.readelement import Element

class WebPage:
    '''
        selenium基类
    '''

    def __init__(self, driver):
        self.driver = driver or webdriver.Chrome()
        self.timeout = 20
        self.wait = WebDriverWait(self.driver, self.timeout)

    def get_url(self, url: str):
        '''
            打开网址并验证是否超时
        :param url: 要打开的网页地址
        :return: None
        '''
        self.driver.maximize_window()
        # 设置超时时间
        self.driver.set_page_load_timeout(60)
        try:
            self.driver.get(url)
            self.driver.implicitly_wait(10)
            log.info(f'打开网页{url}')
        except TimeoutException:
            raise TimeoutException(f"打开{url}超时请检查网络或网址服务器")

    @staticmethod
    def element_locator(func, locator):
        '''
            元素定位器:元素是以哪种方式定位的
        :param func: 一个显示等待的函数
        :param locator: 读取元素配置文件得到的具体元素
        :return: 执行函数
        '''
        name, value = locator
        return func(cm.LOCATE_MODE[name], value)

    def find_element(self, locator):
        '''

        :param locator:读取元素配置文件得到的具体元素
        :return: 单个元素
        '''
        return WebPage.element_locator(lambda *args: self.wait.until(
            EC.presence_of_element_located(args)
        ), locator)

    def find_elements(self,locator):
        '''

        :param locator: 读取元素配置文件得到的具体元素
        :return: 所有元素
        '''
        return WebPage.element_locator(lambda *args: self.wait.until(
            EC.presence_of_all_elements_located(args)
        ), locator)

    def elements_num(self,locator):
        '''
        获取相同元素的个数
        :return:个数
        '''
        number=len(self.find_elements(locator))
        log.info(f'相同元素{locator}有{number}')
        return number

    def input_text(self,locator,txt):
        '''
        输入前要清空
        :param locator: 读取元素配置文件得到的具体元素
        :param txt:  要输入的文本
        :return:None
        '''
        sleep(0.5)
        ele=self.find_element(locator)
        ele.clear()
        ele.send_keys(txt)
        log.info(f'输入文本{txt}')

    def one_click(self,locator):
        '''
            单击
        :param locator:读取元素配置文件得到的具体元素
        :return:None
        '''
        self.find_element(locator).click()
        sleep()
        log.info("点击元素：{}".format(locator))

    def element_text(self,locator:Element):
        '''
            获取当前元素的text
        :param locator:
        :return: 文本
        '''
        try:
            _text=self.find_element(locator).text
            return _text
        except Exception:
            log.info('{locator}元素没有文本')
            raise Exception('{locator}元素没有文本')
    @property
    def get_source(self):
        '''
            获取页面源代码
        :return:
        '''
        return self.driver.page_source

    def refresh(self):
        '''
            刷新页面
        :return:None
        '''
        self.driver.refresh()
        self.driver.implicitly_wait(30)







if __name__ == '__main__':
    pass
