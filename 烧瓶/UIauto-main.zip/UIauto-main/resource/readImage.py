#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:程旭23476
@file:readImage.py
@time:2021/12/30
"""
from config.conf import cm
import os


class ReadImage:
    '''
        配置图片路径
    '''

    # 微信图标
    IMAGE = {
        '微信': {
            '微信图标': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'icon.png'),
            '搜索框': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'search.png'),
            '文件传输助手': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'helper.png'),
            '文件传输聊天框': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'text.png'),
            '发送': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'send.png'),
            '关闭': os.path.join(cm.BASE_DIR, 'resource', 'image', 'wechat', 'close.png'),
        },
        'QQ': {
            '更多': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'more.png'),
            '在线': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'online.png'),
            '离开': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'leave.png'),
            'Q我': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'Q.png'),
            '忙绿': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'busy.png'),
            '搜索框': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'search.png'),
            '输入框': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'text.png'),
            '我的iPhone': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'myiphone.png'),
            '关闭': os.path.join(cm.BASE_DIR, 'resource', 'image', 'QQ', 'close.png'),
        },
        '认证助手': {
            '用户名': os.path.join(cm.BASE_DIR, 'resource', 'image', 'identification', 'user.png'),
            '断开': os.path.join(cm.BASE_DIR, 'resource', 'image', 'identification', 'exit.png'),
        }

    }


if __name__ == '__main__':
    print(ReadImage.IMAGE['微信']['搜索框'])
