#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:readelement.py
@time:2021/10/29
封装读取元素文件类
"""
import os
import yaml
from config.conf import cm
from utils.logger import log
class Element:
    '''
        获取元素
    '''
    def __init__(self,name):
        self.file_name=f'{name}.yaml'
        self.element_path=os.path.join(cm.ELEMENT_PATH,self.file_name)
        log.info(f'文件路径{self.element_path}')
        if not os.path.exists(self.element_path):
            raise FileNotFoundError(f'{self.element_path}文件不存在!')
        with open(self.element_path,encoding='utf-8') as f:
            cfg=f.read()
            self.data=yaml.load(cfg,Loader=yaml.Loader)

    def __getitem__(self, item):
        '''
            获取属性
        :param item: yaml中element的key
        :return: 具体的值
        '''

        data=self.data.get(item)
        if data:
            name,value=data.split('==')
            return name,value
        raise ArithmeticError(f'{self.file_name}中不存在关键字:{item}')






if __name__ == '__main__':
    search=Element('search')
    name,value=search['候选']
    print(name)
    print(value)
    print('--')
