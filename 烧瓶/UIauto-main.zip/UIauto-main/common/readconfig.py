#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:readconfig.py
@time:2021/10/19
"""

import configparser
from config.conf import cm

HOST = 'HOST'


class ReadConfig:
    def __init__(self):
        self.config = configparser.RawConfigParser()
        self.config.read(cm.ini_file, encoding='utf-8')

    def _get(self, section, option):
        '''
            获取
        :param section: 配置文件中段名称
        :param option:  段中的key值
        :return:        段中的value值
        '''
        return self.config.get(section, option)

    def _set(self, section, option, value):
        '''
            更新数据
        :param section: 配置文件中段名称
        :param option:  段中的key值
        :param value:   段中的value值
        :return: None
        '''
        self.config.set(section, option, value)
        with open(cm.ini_file, 'w') as f:
            self.config.write(f)

    @property
    def url(self):
        return self._get(HOST,HOST)




ini=ReadConfig()
if __name__ == '__main__':
    print(ini.url)
