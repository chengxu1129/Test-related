#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:searchpage.py
@time:2021/11/18
页面对象
"""


from page.webpage import WebPage,sleep
from common.readelement import Element

search=Element('search')
class SearchPage(WebPage):
    '''
        搜索类
    '''
    def input_search(self,content):
        '''

        :param content: 输入搜索内容
        :return: None
        '''
        self.input_text(search['搜索框'],txt=content)
        sleep(1)

    def click_search(self):
        '''
            点击搜索
        :return: None
        '''
        self.one_click(search['搜索按钮'])









if __name__ == '__main__':
    pass
