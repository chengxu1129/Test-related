#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:程旭23476
@file:operateapp.py
@time:2021/12/30
封装图像识别操作
"""
import win32gui
from airtest.core.api import *
from airtest.aircv import *
from PIL import ImageGrab
from airtest.core.helper import G, logwrap

from resource.readImage import ReadImage
from config.conf import cm
from utils.logger import log


# win下的
class OperateApp:

    def connect_desktop(self):
        '''
            连接整个window桌面baohan
        '''
        try:
         auto_setup(__file__, devices=["Windows:///"])
        except Exception:

            log.error('连接window窗口失败')
            raise Exception('连接window窗口失败')

    def get_window_pos(self, name):
        '''
            判断软件是否已开启
        :param name: 软件名字
        :return: 返回window句柄
        '''
        self.handle = win32gui.FindWindow(None, name)

        if self.handle == 0:
            print('没获取到应用句柄')
            log.info(f'{name}没有开启')
            exit()
            # return None
        else:
            return self.handle

    def snapShot(self, name, quality=99):
        '''
        截全屏
        :param name: 截图的名字
        :param quality  图片的清晰度[1~99]
        :return: 返回截图名字和大小
        '''
        screen = G.DEVICE.snapshot()
        print(screen)
        # screen = ImageGrab.grab()
        filename = f"{name}.jpg"
        filepath = os.path.join(cm.SNAPSHOT, filename)
        if screen is not None:
            # screen.save(filepath)
            aircv.imwrite(filepath, screen, quality)
            # return {"screen": filename, "resolution": screen.size}
            return {"screen": filename, "resolution": aircv.get_resolution(screen)}

    def readShot(self, name):
        '''
        读取截图
        :param name: 读取的截图名字
        :return: cv2的图片处理格式
        '''
        src_path = os.path.join(cm.SNAPSHOT, f'{name}.jpg')
        return aircv.imread(src_path)

    def readShot_template(self, model, name):
        '''
        读取模板
        :param name: 读取的截图名字
        :return: cv2的图片处理格式
        '''
        icon = ReadImage.IMAGE[model][name]
        return aircv.imread(icon)

    def cropImage(self, source, save, num: tuple):
        '''
        对图片进行局部截图
        :param source: 完整的图片名字
        :param save:   截图后图片名字
        :param num:   4个角的坐标
        :return:
        '''
        screen = self.readShot(source)
        new_s = aircv.crop_image(screen, num)
        filename = f"{save}.jpg"
        filepath = os.path.join(cm.SNAPSHOT, filename)
        if screen is not None:
            aircv.imwrite(filepath, new_s)
            return {"screen": filename, "resolution": aircv.get_resolution(new_s)}

    def cropScreen(self, name, num: tuple):
        '''
            对屏幕进行局部截图
        :param name:截图的名字
        :param num: 局部的4角位置
        :return: 返回截图名字和大小
        '''
        screen = ImageGrab.grab(num)
        filename = f"{name}.jpg"
        filepath = os.path.join(cm.SNAPSHOT, filename)
        if screen is not None:
            screen.save(filepath)
            return {"screen": filename, "resolution": screen.size}

    def loopFind(self, query, timeout=5, interval=0.5, ):
        '''

        :param query: 目标图片
        :param timeout: 超时时间
        :param interval: 停顿时间
        :return:图片的坐标
        '''
        start_time = time.time()
        while True:
            screen = G.DEVICE.snapshot(filename=None, quality=ST.SNAPSHOT_QUALITY)
            if screen is None:
                G.LOGGING.warning("Screen is None, may be locked")
            else:
                match_pos = query.match_in(screen)
                if match_pos:
                    return match_pos
            # 超时则raise，未超时则进行下次循环:
            if (time.time() - start_time) > timeout:
                log.info(f'找不到{query}')
                raise TargetNotFoundError('Picture %s not found in screen' % query)
            else:
                time.sleep(interval)

    def oaExists(self, model, name, timeout=5):
        '''
        判断图片是否存在
        :param model: 要寻找的模块名称
        :param name:  要寻找的模块下的图标名称
        :param timeout: 超时时间
        :return: 图片的坐标
        '''
        try:
            icon = ReadImage.IMAGE[model][name]
            pos = self.loopFind(Template(icon), timeout=timeout)
        except Exception as e:
            #log.info(e)
            return False
        else:
            return pos

    def oaTouch(self, model, name):
        '''

        :param model: app名字
        :param name:  要单击的图片icon名称
        :return: None
        '''
        pos = self.oaExists(model, name)
        if pos:
            touch(pos)
            return True
        else:
            log.info(f'图片{model}下{name}没找到')
            raise TargetNotFoundError(f'Picture {model}下{name}%s not found in screen' )


    def doubleTouch(self, model, name):
        '''

        :param model: app名字
        :param name:  要双击的图片icon名称
        :return: None
        '''
        pos = self.oaExists(model, name)
        if pos:
            double_click(pos)
            return True
        else:
            log.info(f'图片{model}下{name}没找到')
            raise TargetNotFoundError(f'Picture {model}下{name}%s not found in screen' )

    def oaWait(self, model, name, timeout=120):
        '''

        :param model:要寻找的模块名称
        :param name:要寻找的模块下的图标名称
        :param timeout: 超时时间
        :return:图片的坐标
        '''
        timeout = timeout or ST.FIND_TIMEOUT
        icon = ReadImage.IMAGE[model][name]
        pos = self.loopFind(Template(icon), timeout=timeout)
        return pos

    def oaText(self, content):
        '''

        :param content: 输入的内容
        :return:
        '''
        return text(content)

    def oaKeyEnter(self):
        '''
        按下回车
        :return:
        '''
        return keyevent("{ENTER}")

    def assertEqual(self, type: int, template_tuple=None, screen=None) -> bool:
        '''
        判断图片是否存在另一张图片内
        :param type: 何种查找 数字类型
        1.模板图片找模板图片
        template_tuple=((xx,xx),(xx,xx))screen
        2.模板图片找截图
        template_tuple=(x,x) screen=截图的名字
        3.截图找截图
        screen=(小图名字,大图名字)
        4.截图找模板
        template_tuple=(x,x) screen=截图的名字

        :param template_tuple:模板图片名字
        :param screen:截图图片名字
        :return: bool
        '''
        match_pos = None
        if type == 1:
            try:
                icon = ReadImage.IMAGE[template_tuple[0][0]][template_tuple[0][1]]
                query = Template(icon)
                tem = self.readShot_template(template_tuple[1][0], template_tuple[1][1])
                match_pos = query.match_in(tem)
            except IndexError:
                log.error('元祖传入的数据数量小于2')
                raise IndexError('元祖传入的数据数量小于2')
        if type == 2:
            try:
                icon = ReadImage.IMAGE[template_tuple[0]][template_tuple[1]]
                query = Template(icon)
                tem = self.readShot(screen)
                match_pos = query.match_in(tem)
            except Exception:
                raise Exception('参数传入的问题')
        if type == 3:
            try:
                icon = src_path = os.path.join(cm.SNAPSHOT, f'{screen[0]}.jpg')
                print(icon)
                query = Template(icon)
                tem = self.readShot(screen[1])
                match_pos = query.match_in(tem)
            except Exception:
                raise Exception('参数传入的问题')
        if type == 4:
            try:
                icon = src_path = os.path.join(cm.SNAPSHOT, f'{screen}.jpg')
                query = Template(icon)
                tem = self.readShot_template(template_tuple[0], template_tuple[1])
                match_pos = query.match_in(tem)
            except Exception:
                raise Exception('参数传入的问题')
        if match_pos:
            return True
        else:
            return False

        # 小图
        # icon = ReadImage.IMAGE[model][name]
        # query=Template(icon)
        # print(query)
        # # 大图
        # tem = self.readShot(screen)
        # 小图是否在大图里


oa = OperateApp()

if __name__ == '__main__':
    oa.connect_desktop()
    print(oa.get_window_pos('Ingress'))
    #print(oa.snapshot('提高'))
    # print(oa.readShot('提高'))
    # oa.cropImage('提高')
    # print(oa.cropImage('提高','new',(0,160,1000,900)))
    # oa.doubleTouch('微信','微信图标')
    # sleep(1)
    #oa.snapShot('cx2',99)
    #print(oa.oaExists('微信','微信图标'))
    # print(oa.assertEqual(1,(('微信', '微信图标'),('微信','搜索框'))))
    #print(oa.assertEqual(3, screen=('1', '2')))
    #print(oa.assertEqual(4, template_tuple=('微信', '微信图标'), screen='1'))


