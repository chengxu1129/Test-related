#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:程旭23476
@file:conftest.py
@time:2022/01/05
"""

import pytest


from app.operateapp import oa



@pytest.fixture()
def connect():
    oa.connect_desktop()
    # print('连接window窗口')


