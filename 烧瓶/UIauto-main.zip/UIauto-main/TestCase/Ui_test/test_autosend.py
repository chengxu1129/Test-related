#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:程旭23476
@file:test_autosend.py
@time:2022/01/05
"""
import pytest
from time import sleep
if __name__ == '__main__':
    pass

from app.operateapp import oa

class Test_auto_send:


    def test_first(self,connect):
        print('连接window窗口')

    def test_wechat(self,):
        try:
            oa.doubleTouch('微信', '微信图标')
            #等待或者wait微信界面出现
            sleep(0.5)
            oa.oaTouch('微信','搜索框')
            sleep(0.5)
            oa.oaText('文件')
            sleep(0.5)
            oa.oaTouch('微信','文件传输助手')
            sleep(0.5)
            oa.oaTouch('微信','文件传输聊天框')
            sleep(0.5)
            oa.oaText('123')
            oa.oaKeyEnter()
            oa.oaText('456')
            oa.oaKeyEnter()
            sleep(0.5)
            oa.oaTouch('微信','关闭')
        except Exception as e:
            pytest.xfail('失败')




    def test_002(self):
        print(2)


if __name__ == "__main__":
    pytest.main(["-s", "test_autosend.py"])

