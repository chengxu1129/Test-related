#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:inspect.py
@time:2021/11/04
"""

import os
import yaml
from config.conf import cm
from utils.times import running_time
from utils.logger import log

@running_time
def inspert_element():
    '''
        检查所有的元素是否正确，简单检查格式
    :return: None
    '''
    for files in os.listdir(cm.ELEMENT_PATH):
        _path=os.path.join(cm.ELEMENT_PATH,files)
        with open(_path,encoding='utf-8') as f:
            data=yaml.safe_load(f)
        for k,v in data.items():
            try:
                pattern,value=v.split('==')
            except:
                log.error(f"{_path}文件中{k}后表达式中`==`不正确")
                raise Exception(f"{_path}文件中{k}后表达式中`==`不正确")
            if pattern not in cm.LOCATE_MODE:
                raise Exception('%s中元素【%s】没有指定类型' % (_path, v))
            elif pattern=='xpath':
                assert '//' in value,f'{_path}中元素{k}的xpath{value}格式不对'
            elif pattern=='css':
                assert '//' not in value, f'{_path}中元素{k}的css{value}格式不对'
            else:
                assert value,f'{_path}中元素{k}的其他{value}格式不对'




if __name__ == '__main__':
    inspert_element()
