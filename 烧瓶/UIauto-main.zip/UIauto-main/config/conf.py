#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:conf.py
@time:2021/10/11
"""
import os
from selenium.webdriver.common.by import By
from utils.times import dt_strftime


class ConfigManager:
    # 项目目录
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # 页面元素目录
    ELEMENT_PATH = os.path.join(BASE_DIR, 'page_element')
    # 报告文件
    REPORT_FILE = os.path.join(BASE_DIR, 'report.html')
    # 截图地址
    SNAPSHOT =os.path.join(BASE_DIR, 'screenshot')



    # 元素定位的类型
    LOCATE_MODE = {
        'css': By.CSS_SELECTOR,
        'xpath': By.XPATH,
        'name': By.NAME,
        'id': By.ID,
        'class': By.CLASS_NAME
    }
    # 邮件信息
    EMAIL_INFO = {
        'username': '1439121381@qq.com',
        'password': 'QQ邮箱授权码',
        'smtp_host': 'smtp.qq.com',
        'smtp_port': 465
    }
    #收件人
    ADDRESSEE=['1439121381@qq.com']

    @property
    def log_file(self) -> str:
        '''
        日志目录路径
        :return: 一个具体当前时间log文件
        '''
        log_dir = os.path.join(self.BASE_DIR, 'logs')
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        return os.path.join(log_dir, f'{dt_strftime("%Y%m%d")}.log')

    @property
    def ini_file(self):
        '''
        配置文件路径
        :return: 返回配置文件目录
        '''
        ini_file=os.path.join(self.BASE_DIR,'config','config.ini')
        if not os.path.exists(ini_file):
            raise FileNotFoundError(f'配置文件{ini_file}不存在！')
        return ini_file

#初始化
cm=ConfigManager()
if __name__ == '__main__':
    print(ConfigManager.BASE_DIR)
    print(cm.ini_file)
