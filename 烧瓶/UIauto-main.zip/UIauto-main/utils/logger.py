#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:logger.py
@time:2021/10/19
"""

import logging
from config.conf import cm


class Log:
    def __init__(self):
        # 1、创建一个logger
        self.logger=logging.getLogger()
        if not self.logger.handlers:
            self.logger.setLevel(logging.DEBUG)
            #创建一个handle写入文件
            fh=logging.FileHandler(cm.log_file,encoding='utf-8')
            fh.setLevel(logging.INFO)
            #创建一个handle输出到控制台
            # ch=logging.StreamHandler()
            # ch.setLevel(logging.INFO)
            #定义输出的格式
            formatter=logging.Formatter(self.__fmt)
            fh.setFormatter(formatter)
            # ch.setFormatter(formatter)
            #给logger添加handler
            self.logger.addHandler(fh)
            # self.logger.addHandler(ch)
    @property
    def __fmt(self):
        return '%(levelname)s\t%(asctime)s\t[%(filename)s:%(lineno)d]\t%(message)s'
log=Log().logger
if __name__ == '__main__':
    log.info('hello world')





























if __name__ == '__main__':
    pass
