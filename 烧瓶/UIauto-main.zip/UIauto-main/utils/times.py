#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:chengx04
@file:times.py
@time:2021/10/18
"""

import time
import datetime
from functools import wraps


def timestamp():
    '''
        获取时间戳函数
    :return: 返回当前时间戳
    '''
    return time.time()


def dt_strftime(fmt='%Y%m'):
    '''

    :param fmt: %Y%m%d %H%M%S
    :return: 返回当前格式化的时间
    '''
    return datetime.datetime.now().strftime(fmt)

def sleep(seconds=1.0):
    '''

    :param seconds:睡眠时间
    :return:None
    '''
    time.sleep(seconds)

def running_time(func):
    '''

    :param func: 要装饰的函数
    :return: 闭包函数
    '''
    @wraps(func)
    def wrapper(*args,**kwargs):
        start=timestamp()
        res=func(*args,**kwargs)
        print('执行时间%.3f秒' %(timestamp()-start))
        return res
    return wrapper

@running_time
def test():
    print(1)




if __name__ == '__main__':
    print(dt_strftime())



