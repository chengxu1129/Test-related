#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
@author:程旭23476
@file:autowechat.py
@time:2022/01/08
"""

class WechatUiAuto:

    pass













if __name__ == '__main__':
    pass
