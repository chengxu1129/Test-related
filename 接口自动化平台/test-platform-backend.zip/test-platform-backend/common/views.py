from django.shortcuts import render

# Create your views here.
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView

from utils.response import APIRespones
from common.models import tbl_common_para

from common.serlizers import CommonParaSerializers


# 公共参数表
class CommPara(ModelViewSet):
    queryset = tbl_common_para.objects.filter()
    serializer_class = CommonParaSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败')
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')
