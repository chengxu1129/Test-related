from django.db import models

# Create your models here.

from serviceline.models import tbl_api_info,tbl_group_case,tbl_project_category
from userauth.models import tbl_user



#公共模块
class tbl_common_para(models.Model):

    project_id  = models.IntegerField()
    create_id   = models.IntegerField()
    create_time = models.DateTimeField(auto_now=True)
    re_heads    = models.CharField(max_length=255, verbose_name="公共请求头", default=None)
    re_method   = models.CharField(max_length=100, verbose_name="请求方式", default=None)
    head_name   = models.CharField(max_length=15, default=None)

    class Meta:
        db_table = 'tbl_common_para'

