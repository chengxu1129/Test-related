from rest_framework import serializers

from common.models import tbl_common_para


class CommonParaSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_common_para
        fields = ('id','project_id','create_id','re_heads','re_method','head_name')
        extra_kwargs = {
            'id': {
                'read_only': True
            }
        }

    def validate_head_name(self, value):
        if tbl_common_para.objects.filter(head_name=value):
            raise serializers.ValidationError('模块名已存在')
        return value