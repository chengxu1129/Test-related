from rest_framework import serializers
from config.models import (tbl_app_envi, tbl_config_hosts, tbl_apiprams_config,
                           tbl_variable_config, tbl_jenkins_serve, tbl_jenkins_project)
from serviceline.models import tbl_group_case, tbl_api_info
from userauth.models import tbl_project_category, tbl_user

from utils.Assert import AssertSrc


class AppEnviSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_app_envi
        fields = ('id', 'app_id', 'environment', 'host')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }


class HostsSerializers(serializers.ModelSerializer):
    class Meta:
        model = tbl_config_hosts
        fields = ('id', 'host')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }


class VariableSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_variable_config
        fields = ('id', 'key', 'value', 'project_id')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }

    def validate(self, attrs):
        if tbl_variable_config.objects.filter(key=attrs['key'], project_id=attrs['project_id'], is_deleted=False).first():
            raise serializers.ValidationError('key已存在')
        return attrs


# 设置公共变量
class ApiParamsSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_apiprams_config
        fields = ('id', 'api_id', 'project_id', 'group_name', 'case_name', 'environment')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }

    group_name = serializers.SerializerMethodField()
    case_name = serializers.SerializerMethodField()

    def validate(self, attrs):
        if tbl_apiprams_config.objects.filter(api_id=attrs['api_id'], project_id=attrs['project_id'],
                                              is_deleted=False).first():
            raise serializers.ValidationError('接口重复选择')
        return attrs

    def get_case_name(self, obj):
        apiid = tbl_apiprams_config.objects.filter(pk__exact=obj.id).values_list('api_id').all()
        casename = tbl_api_info.objects.filter(id__in=apiid).all()
        ret = []
        for item in casename:
            ret = item.case_name
        return ret

    def get_group_name(self, obj):
        groupid = tbl_api_info.objects.filter(pk__exact=obj.api_id).values_list('group_id').all()
        groupname = tbl_group_case.objects.filter(id__in=groupid).all()
        rets = []
        for item in groupname:
            rets= item.groupname
        return rets


# 邮件序列化
class SendEmailSerializers(serializers.ModelSerializer):

    class Meta:

        model = tbl_project_category
        fields = ('id', 'pro_name', 'send_email', 'list_email')
        extra_kwargs = {
            'id': {
                'read_only': True,
            },
            'pro_name': {
                'read_only': True,
            },
        }

    send_email = serializers.SerializerMethodField()
    list_email = serializers.SerializerMethodField()

    def get_list_email(self, obj):
        objs = eval(obj.send_email)
        email_name = tbl_user.objects.filter(id__in=objs).all()
        res = []
        for item in email_name:
            res.append(item.email)
        return res

    def get_send_email(self, obj):
        return eval(obj.send_email)


# jenkins列表展示
class JenkinsListSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_jenkins_serve
        fields = ('id', 'jenkins_name')
        extra_kwargs = {
            'id': {
                'read_only': True,
            },
        }


# jenkins对应的project
class JenkinsProjectSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_jenkins_project
        fields = ('id', 'jenkins_id', 'project_id')
        extra_kwargs = {
            'id': {
                'read_only': True,
            },
        }

    def validate(self, attrs):
        if tbl_jenkins_project.objects.filter(jenkins_id=attrs['jenkins_id'],
                                              project_id=attrs['project_id'], is_deleted=False).first():
            raise serializers.ValidationError('对应关系已存在')
        return attrs
