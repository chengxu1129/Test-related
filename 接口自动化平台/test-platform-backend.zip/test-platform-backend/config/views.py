import time

from django.http import JsonResponse
from django.shortcuts import render
from django.template import loader

# Create your views here.
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
import json
from django.conf import settings
from django.core.mail import EmailMultiAlternatives

from serviceline.views import get_cur_envir
from utils.Assert import AssertSrc
from utils.ali_dingtalk import DingtalkRobot
from utils.jsoncode import DateEncoder

import requests
from utils.response import APIRespones
from userauth.models import tbl_project_category
from config.serlizers import (AppEnviSerializers, HostsSerializers, VariableSerializers,
                              ApiParamsSerializers, SendEmailSerializers, JenkinsListSerializers,
                              JenkinsProjectSerializers)
from config.models import (tbl_app_envi, tbl_config_hosts, tbl_variable_config,
                           tbl_apiprams_config, tbl_jenkins_serve, tbl_jenkins_project)
from serviceline.models import tbl_group_case
from userauth.models import tbl_user
from utils.methodrequest import MethodRequest
from utils.logger import logger


# 环境的增删改查
class AppEnvi(ModelViewSet):
    queryset = tbl_app_envi.objects.filter()
    serializer_class = AppEnviSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败')
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


class Apps(APIView):
    def get(self, request, *args, **kwargs):
        obj = kwargs.get('app_id')
        objs = tbl_app_envi.objects.filter(app_id=obj)
        obj_ser = AppEnviSerializers(objs, many=True)
        return APIRespones(obj_ser.data)


# 拿所有的Host
class GetHosts(MethodRequest):
    authentication_classes = []
    queryset = tbl_config_hosts.objects.filter()
    serializer_class = HostsSerializers


def get_hosts(request):
    token = request.META.get("HTTP_AUTHORIZATION")
    envir = get_cur_envir(token)
    virable = {"environment": envir}
    obj = tbl_config_hosts.objects.values('id', 'host').distinct()
    list_data = []
    try:
        for data in obj:
            json_da = AssertSrc(virable).update_yaml_info(data)
            list_data.append(json_da)

    except Exception as e:
        pass
    data = {
        "status": "1000",
        "msg": "ok",
        "succese": "true",
        "results": list_data
    }
    return JsonResponse(data)


# 公共常量
class VariableConfig(MethodRequest):
    def retrieve(self, request, *args, **kwargs):
        project_id = kwargs.get('project_id')
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        obj = tbl_variable_config.objects.filter(project_id=project_id, is_deleted=False,environment=envir)
        bs = VariableSerializers(obj, many=True)
        return APIRespones(1000, 'ok', results=bs.data)

    def create(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        params = request.data
        if isinstance(params[0], dict):
            s = [i['key'] for i in params]
            ids = [i['id'] for i in params]

            pro_id = params[0]['project_id']
            obj = tbl_variable_config.objects.filter(project_id=pro_id, is_deleted=False,environment=envir).values('id').all()
            tblid = eval(json.dumps(list(obj), cls=DateEncoder, ensure_ascii=False))
            tblid = [i['id'] for i in tblid]
            ret = [i for i in tblid if i not in ids]
            if len(s) == len(set(s)):
                if len(ret) > 0:
                    for k in ret:
                        obj = tbl_variable_config.objects.get(id=k)
                        obj.is_deleted = True
                        obj.save()
                for i in params:
                    if tbl_variable_config.objects.filter(id=i['id']).first():
                        tbl_variable_config.objects.filter(id=i['id']).update(key=i['key'], value=i['value'])
                    else:
                        tbl_variable_config.objects.create(key=i['key'], value=i['value'], project_id=i['project_id'], environment=envir)
                return APIRespones(1000, 'ok')
            else:
                return APIRespones(1001, '存在key重复', False)
        else:
            obj = tbl_variable_config.objects.filter(project_id=params[0], is_deleted=False,
                                                     environment=envir).values('id').all()
            tblid = eval(json.dumps(list(obj), cls=DateEncoder, ensure_ascii=False))
            tblid = [i['id'] for i in tblid]
            for k in tblid:
                obj = tbl_variable_config.objects.get(id=k)
                obj.is_deleted = True
                obj.save()
            return APIRespones(1000, 'ok')


# API接口配置
class ApiParamsConfig(MethodRequest):
    queryset = tbl_apiprams_config.objects.filter(is_deleted=False)
    serializer_class = ApiParamsSerializers

    def retrieve(self, request, *args, **kwargs):
        project_id = kwargs.get('project_id')
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        obj = tbl_apiprams_config.objects.filter(project_id=project_id, is_deleted=False, environment=envir)
        bs = ApiParamsSerializers(obj, many=True)
        return APIRespones(1000, 'ok', results=bs.data)

    def create(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        request.data["environment"] = envir
        response = super().create(request, *args, **kwargs)
        return response


# 删除配置
class DeleteConfig(MethodRequest):
    queryset = tbl_apiprams_config.objects.filter(is_deleted=False)
    serializer_class = ApiParamsSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败')
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 发送邮件
class SendEmail(APIView):

    def post(self, request, *args, **kwargs):
        try:
            text_content = '这是一封测试报告邮件.'
            objs = request.data
            logger.info("sendEmail_apiInfo", objs)
            s = objs['apiresult'].replace('false', '0')
            subject = '{}接口自动化测试报告'.format(objs['pro_name'])
            s = s.replace('true', '1')
            a = eval(s)
            s_count = 0
            f_count = 0
            lis = []
            for k, v in a['response'].items():
                fail_count = 0
                suc_count = 0
                s = {}
                s['groupname'] = k
                for i in v:
                    if i['msg'] > 0:
                        s_count += 1
                        suc_count += 1
                    elif i['msg'] == 0:
                        f_count += 1
                        fail_count += 1
                s['fail_count'] = fail_count
                s['suc_count'] = suc_count
                lis.append(s)
            context = {
                'project_id': objs['project_id'],
                'fullname': objs['fullname'],
                'start_time': objs['start_time'],
                'end_time': objs['end_time'],
                'apiresult': lis,
                's_count': s_count,
                'f_count': f_count,
                'pro_name': objs['pro_name'],
                'report_id': objs['id'],
            }
            token = request.META.get("HTTP_AUTHORIZATION")
            envir = get_cur_envir(token)
            if s_count != 0:
                fail_rate = f_count/(s_count+f_count)
                cur_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
                host = "http://autotest.codemao.cn/detail/"
                path = context["report_id"]
                pro_name = context["pro_name"]
                url = host + str(path)
                if fail_rate >= 0.2:
                    mark_down_text = f'#### {envir}环境测试用例执行告警\n> {pro_name}测试用例执行完成，统计结果：失败{f_count}条，共运行{(s_count+f_count)}条用例，达到了告警阈值\n> ###### {cur_time}提示，详情点击查看 [测试报告]({url}) \n'
                    DingtalkRobot().send_markdown("用例执行预警", mark_down_text, [])
            email_template_name = 'send_mail.html'
            t = loader.get_template(email_template_name)
            content = t.render(context)
            from_email = settings.DEFAULT_FROM_EMAIL
            receive_email_addr = objs['email_list']
            msg = EmailMultiAlternatives(subject, text_content, from_email, receive_email_addr)
            msg.attach_alternative(content, "text/html")
            msg.send()
        except Exception as e:
            logger.info("EmailError", e)
            return APIRespones(1001, '发送失败', results=e)
        return APIRespones(1000, 'ok', results=context)


# 邮件配置
class EmailInfo(MethodRequest):
    queryset = tbl_project_category.objects.filter(is_deleted=False)
    serializer_class = SendEmailSerializers

    def retrieve(self, request, *args, **kwargs):
        ids = kwargs.get('pk')
        obj = tbl_project_category.objects.filter(is_deleted=False, pk=ids)
        bs = SendEmailSerializers(obj, many=True)

        return APIRespones(1000, 'ok', results=bs.data)

    def create(self, request, *args, **kwargs):
        param = request.data
        tbl_project_category.objects.filter(id=param['id'],
                                            is_deleted=False).update(send_email=param['send_email'])
        return APIRespones(1000, 'OK')


# jenkins服务列表
class JenkinsListQuery(MethodRequest):
    queryset = tbl_jenkins_serve.objects.filter(is_deleted=False)
    serializer_class = JenkinsListSerializers


# jenkins关联项目
class JenkinsProject(MethodRequest):
    authentication_classes = []
    queryset = tbl_jenkins_project.objects.filter(is_deleted=False)
    serializer_class = JenkinsProjectSerializers


# 根据传过来的jenkins服务名去执行项目
class RunJenkinsServe(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        request_data = request.data
        print("请求参数：", request_data)
        # url = "http://127.0.0.1:8000"
        # url = "https://dev-platform-test.codemao.cn"
        url = "https://platform-test.codemao.cn"
        obj = request.data
        ids = tbl_jenkins_serve.objects.filter(jenkins_name=obj['jenkins_name']).values('id').all()
        projects = tbl_jenkins_project.objects.filter(jenkins_id__in=ids,
                                                      is_deleted=False).all()
        result_list = [item.project_id for item in projects]
        for item in result_list:
            login_data = {
                            "username": "yangjian",
                            "password": "yang4112478"
                        }
            login_user = requests.post(url+"/api/login/", json=login_data)
            login_user = login_user.json()
            group_id = tbl_group_case.objects.filter(project_id=item,
                                                     environment=obj['environment'],
                                                     is_deleted=False).all()
            group_ids = [item.id for item in group_id]
            header = {
                "Authorization": login_user["results"]["token"],
                "Content-Type": "application/json"
                }
            tbl_user.objects.filter(id=login_user["results"]["id"]).update(cur_envir=obj['environment'])
            project_body = {"group_ids": str(group_ids), "project_id": item}
            response = requests.post(url+"/api/project/run/", json=project_body, headers=header)
            response = response.json()
            if response['status'] == 1000:
                report_body = {
                    "group_ids": str(group_ids),
                    "project_id": item,
                    "start_time": response['results']['start_time'],
                    "end_time": response['results']['end_time'],
                    "fullname": '系统',
                    "apiresult": json.dumps(response['results']),
                    "environment": obj['environment'],
                }

                # 写入报告
                report_respones = requests.post(url+"/api/project/pro_report/",
                                                json=report_body, headers=header)

                report_respones = report_respones.json()

                # 获取邮箱
                email_list = requests.get(url+"/api/setEmail/{}".format(item),
                                          headers=header)
                email_list = email_list.json()
                if email_list['status'] == 1000:
                    report_respones['results']['email_list'] = email_list['results'][0]['list_email']
                    # 发送邮件
                    send_mail = requests.post(url+"/api/sendEmail/",
                                              json=report_respones['results'], headers=header)
                    send_mail = send_mail.json()
                    print('jenkins自动运行项目邮件推送：{}'.format(send_mail))

            else:
                return APIRespones(1001, '运行失败', results=response)

        return APIRespones(1000, '运行成功')












