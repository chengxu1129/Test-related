from django.db import models

# Create your models here.
from serviceline.models import tbl_app


#接口运行环境配置表
class tbl_app_envi(models.Model):

    app_id = models.IntegerField()
    environment = models.CharField(max_length=10,verbose_name='运行环境')
    host = models.CharField(max_length=50,verbose_name='域名')

    class Meta:
        db_table = 'tbl_app_envi'


class tbl_config_hosts(models.Model):
    host = models.CharField(max_length=255, verbose_name="HOST")

    class Meta:
        db_table = 'tbl_config_hosts'


class tbl_variable_config(models.Model):
    key = models.CharField(max_length=25, verbose_name="变量名")
    value = models.TextField(verbose_name="变量值")
    environment = models.CharField(max_length=10, verbose_name='运行环境')
    project_id = models.CharField(max_length=25, verbose_name="项目id")
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_variable_config'


class tbl_apiprams_config(models.Model):
    api_id = models.CharField(max_length=25, verbose_name="接口id")
    project_id = models.CharField(max_length=25, verbose_name="项目id")
    environment = models.CharField(max_length=25, verbose_name="环境")
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_apiprams_config'


class tbl_jenkins_serve(models.Model):
    jenkins_name = models.CharField(max_length=225, verbose_name='jenkins项目名')
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_jenkins_serve'


class tbl_jenkins_project(models.Model):
    jenkins_id = models.CharField(max_length=25, verbose_name='jenkins列表ID')
    project_id = models.CharField(max_length=25, verbose_name='项目id')
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_jenkins_project'
