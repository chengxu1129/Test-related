import json

import requests
import jsonpath
import time
from request.needvalue import GetDicValue, c
from utils.logger import logger
from utils.Assert import AssertSrc


def need_time():
    return int(time.time())

class RequestInfo():
    def __init__(self, data=None, header=None, path=None,
                 method=None, aseert=None, st_code=None,
                 casename=None,):
        self.data = data
        self.header = header
        self.path = path
        self.aseert = aseert
        self.st_code = st_code
        self.method = method
        self.casename = casename


    def request_api(self):
        try:
            if self.method.upper() == 'POST':
                result = requests.post(self.path, json=self.data, headers=self.header)
                return result
            if self.method.upper() == 'GET':
                result = requests.get(self.path, headers=self.header)
                return result
            if self.method.upper() == 'DELETE':
                result = requests.delete(self.path, headers=self.header, json=self.data)
                return result
            if self.method.upper() == 'PATCH':
                result = requests.patch(self.path, json=self.data, headers = self.header)
                return result
            if self.method.upper() == 'PUT':
                result = requests.put(self.path, json=self.data, headers=self.header)
                return result

        except Exception as e:
            print('requestError:', e)
            return '不存在的请求：{}'.format(e)

# 执行整个用例组
    def requstelist(self, list, value):
        values = value
        lists = []
        dic = {}
        try:
            for qs in list:

                self.casename = qs["case_name"]
                self.header = eval(qs["re_head"])
                self.path   = qs["st_host"] + qs["re_path"]
                self.st_code = qs["st_code"]
                self.method = qs["methods"]
                self.need_value = qs["need_value"]

                if '$' in self.path:
                    self.path = self.replacevalue(values, self.path)

                if '$' in qs["re_head"]:
                    header = self.replacevalue(values, qs["re_head"])
                    self.header = eval(header)
                    qs["re_head"] = header

                if self.method == 'post' or self.method == 'put' or self.method == 'patch' or self.method == 'delete':
                    if '$' in qs["re_body"]:
                        data = self.replacevalue(values, qs["re_body"])
                        self.data = eval(data)
                        qs["re_body"] = data
                    elif qs["re_body"] == "":
                        self.data = {}
                    else:
                        self.data = eval(qs["re_body"])

                response = self.request_api()

                qs["re_url"] = self.path


                try:
                    st_code  = response.status_code

                except:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    lists.append(dic.copy())
                    continue
                try:
                    response = response.json()
                except Exception as e:
                    response = "error,返回值不是json格式"
                    pass

                if self.st_code == str(st_code):
                    if self.need_value != '':

                        try:
                            for k, v in eval(self.need_value).items():
                                values[k] = jsonpath.jsonpath(response, v)
                        except Exception as e:
                            print("needValueError:", e)
                            pass


                    dic["msg"] = 1
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    if qs["asserts"] != '':
                        self.aseert = eval(qs["asserts"])
                        aserrts = self.func(response, self.aseert, dic["msg"])
                        dic["msg"] = aserrts
                        lists.append(dic.copy())
                    else:
                        lists.append(dic.copy())
                else:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    lists.append(dic.copy())
            print('api_response', lists, 'needValueall', values)
            return lists

        except Exception as e:
            print("request_api:", e)
            return self.casename

    # 执行整个用例组
    def run_testcase(self, list, value: dict, envir="test"):
        """

        :param list: 需要运行的接口信息顺序列表
        :param value: 变量存放的值为dict
        :return:
        """
        values = value
        values["environment"] = envir
        lists = []
        dic = {}
        try:
            for case in list:
                # 处理传入的json数据格式
                for k, v in case.items():
                    if isinstance(v, str):
                        if '{' in v:
                            v.replace("\n", "")
                            v = json.loads(v)
                            case[k] = v
                self.need_value = case.pop("need_value")

                try:
                    update_case = AssertSrc(values).update_yaml_info(case)
                except Exception as e:
                    update_case = case
                    print(f"json数据批量更新时出现错误{e}")
                self.path = update_case["st_host"]+update_case["re_path"]
                self.casename = update_case["case_name"]
                self.header = update_case["re_head"]
                self.method = update_case["methods"]
                self.st_code = update_case["st_code"]
                if update_case["re_body"]=="":
                    update_case["re_body"] = {}
                else:
                    self.data = update_case["re_body"]
                response = self.request_api()
                try:
                    st_code = response.status_code
                except:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = update_case
                    dic["response"] = response
                    lists.append(dic.copy())
                    continue
                try:
                    response = response.json()
                except Exception as e:
                    response = "error,返回值不是json格式"
                    pass
                # 此处开始进行变量值的精准提取操作
                if self.st_code == str(st_code):
                    if self.need_value != '':
                        try:
                            GetDicValue(response)
                            # 之前存在冲突去掉双重取值，采用逻辑判断
                            for k, v in self.need_value.items():
                                if '.' in v:
                                    # 判断jsonpath格式是否满足要求
                                    if jsonpath.jsonpath(response, v):
                                        values[k] = jsonpath.jsonpath(response, v)[0]
                                    else:
                                        values[k] = v
                                else:
                                    values[k] = c[v]
                        except Exception as e:
                            print(f"needValueError:{e}")

                    dic["msg"] = 1
                    dic["casename"] = self.casename
                    dic["re_info"] = update_case
                    dic["response"] = response
                    if update_case["asserts"] != '':
                        self.aseert = eval(update_case["asserts"])
                        aserrts = self.func(response, self.aseert, dic["msg"])
                        dic["msg"] = aserrts
                        lists.append(dic.copy())
                    else:
                        lists.append(dic.copy())
                else:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = update_case
                    dic["response"] = response
                    lists.append(dic.copy())
            print('api_response', lists, 'needValueall', values)
            return lists

        except Exception as e:
            print("request_api:", e)
            return self.casename

# 执行整个项目
    def requstePro(self, lists, value, envir):
        lis = []
        for qa in lists:
            param = value.copy()
            response = self.run_testcase(qa, param, envir)
            if isinstance(response, list):
                lis.append(response)
            else:
                return response
        return lis

    def func(self,para,aseert=None,count=0):
        if str(aseert).strip('{}') in str(para).strip():
            count += 1
            return count
        else:
            count -=1
            return count

    def replacevalue(self, ne_value, repvalue):
        if ne_value == {}:
            return repvalue
        for i, ne_values in ne_value.items():
            if "$" + i in repvalue:
                if "need_time()" in ne_values:
                    repvalue = repvalue.replace("$" + i, str(eval(ne_values)))
                else:
                    repvalue = repvalue.replace("$" + i, str(ne_values))
        return repvalue
