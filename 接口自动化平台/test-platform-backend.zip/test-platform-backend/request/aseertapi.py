import requests
import json, time
from request.needvalue import GetDicValue, c
from utils.logger import logger

def need_time():
    return int(time.time())
class RequestInfo():

    def __init__(self, data=None, header=None, path=None,
                 method=None, aseert=None, st_code=None,
                 casename=None,):
        self.data = data
        self.header = header
        self.path = path
        self.aseert = aseert
        self.st_code = st_code
        self.method = method
        self.casename = casename



    def request_api(self):
        try:
            if self.method.upper() == 'POST':
                result = requests.post(self.path, json=self.data, headers=self.header)
                return  result
            if self.method.upper() == 'GET':
                result = requests.get(self.path, headers=self.header)
                return  result
            if self.method.upper() == 'DELETE':
                result = requests.delete(self.path, headers=self.header, json=self.data)
                return  result
            if self.method.upper() == 'PATCH':
                result = requests.patch(self.path, json=self.data, headers = self.header)
                return  result
            if self.method.upper() == 'PUT':
                result = requests.put(self.path, json=self.data, headers=self.header)
                return  result

        except Exception as e:
            return ('不存在的请求：{}'.format(e))

#执行整个用例组
    def requstelist(self, list ):
        values = {}
        lists = []
        dic = {}
        try:
            for qs in list:
                self.casename = qs["case_name"]
                self.header = eval(qs["re_head"])
                self.path   = qs["st_host"] + qs["re_path"]
                self.st_code = qs["st_code"]
                self.method = qs["methods"]
                self.need_value = qs["need_value"]

                if '$' in self.path:
                    self.path = self.replacevalue(values, self.path)

                if '$' in qs["re_head"]:
                    header = self.replacevalue(values, qs["re_head"])
                    self.header = eval(header)
                    qs["re_head"] = header

                if self.method == 'post' or self.method == 'put' or self.method == 'patch' or self.method == 'delete':
                    if '$' in qs["re_body"]:
                        data = self.replacevalue(values, qs["re_body"])
                        self.data = eval(data)
                        qs["re_body"] = data
                    elif qs["re_body"] == "":
                        self.data = {}
                    else:
                        self.data = eval(qs["re_body"])

                response = self.request_api()

                qs["re_url"] = self.path


                try:
                    st_code  = response.status_code

                except:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    lists.append(dic.copy())
                    continue
                try:
                    response = response.json()
                except Exception as e:
                    print('没有返回数据:{}'.format(e))

                if self.st_code == str(st_code):
                    if self.need_value != '':

                        try:
                            GetDicValue(response)
                            for k, v in eval(self.need_value).items():
                                values[v] = str(c[k])
                        except  Exception as e:
                            pass
                    dic["msg"] = 1
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    if qs["asserts"] != '':
                        self.aseert = eval(qs["asserts"])
                        aserrts = self.func(response, self.aseert, dic["msg"])
                        dic["msg"] = aserrts
                        lists.append(dic.copy())
                    else:
                        lists.append(dic.copy())
                else:
                    dic["msg"] = 0
                    dic["casename"] = self.casename
                    dic["re_info"] = qs
                    dic["response"] = response
                    lists.append(dic.copy())

            return values
        except Exception as e:
            logger.info("commonError", e)
            return self.casename

    def func(self,para,aseert=None,count=0):
        if str(aseert).strip('{}') in str(para).strip():
            count += 1
            return count
        else:
            count -=1
            return count

    def replacevalue(self, ne_value, repvalue):
        if ne_value == {}:
            return repvalue
        for i, ne_values in ne_value.items():
            if "$" + i in  repvalue:
                if "need_time()" in ne_values:
                    repvalue = repvalue.replace("$" + i, str(eval(ne_values)))
                else:
                    repvalue = repvalue.replace("$" + i, str(ne_values))

        return repvalue
