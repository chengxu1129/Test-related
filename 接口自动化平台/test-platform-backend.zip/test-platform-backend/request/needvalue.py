c ={}
class GetDicValue(object):

    def __init__(self, d):
        self.d = d
        if isinstance(self.d, dict):
            for a, b in self.d.items():
                if isinstance(b, (list, tuple)):
                    setattr(self, a, [GetDicValue(x) if isinstance(x, dict) else x for x in b])
                    c[a] = d[a]
                else:
                    setattr(self, a, GetDicValue(b) if isinstance(b, dict) else b)
                    c[a] = d[a]
        elif isinstance(self.d, (list, tuple)):
            for lis in self.d:
                if isinstance(lis, dict):
                    GetDicValue(lis)
