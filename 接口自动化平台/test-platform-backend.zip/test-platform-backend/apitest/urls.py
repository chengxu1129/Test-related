"""apitest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from common.views import CommPara
from config.views import (AppEnvi, Apps, GetHosts, VariableConfig,
                          ApiParamsConfig, DeleteConfig, SendEmail,
                          EmailInfo, get_hosts, JenkinsListQuery,
                          RunJenkinsServe, JenkinsProject)
from userauth.views import (Register, CgePsw, ProjectInfo, LoginViewSet, UserPro,
                            UserBindPro, OrdinaryUser, QueryEmail, DepartView, ProDepartView,
                            UserDepartPro, UserOperation)
from serviceline.views import (GroupCaseInfo, ApplineInfo, ApiInfo, BusinessLine, GroupApi,
                               ApiGroup, RunApi, RecordsView, AddRecord, GroupRequest,
                               ProjectRequest, ProjectInform, GroupReport, RecordList,
                               ApiTime, ResultsCount, CaseTotal)
from rest_framework.routers import DefaultRouter
from testtools.landing_views import PhoneQuery
from testtools.platform_account_views import CheckPhoneRegistered
from testtools.btoc_views import DeleteUser

urlpatterns = [
    # 用户类
    url(r'^admin/', admin.site.urls),
    url(r'^api/register/', Register.as_view()),
    url(r'^api/registerid/(?P<pk>.*)$', Register.as_view()),
    # 用户拿到对应的项目
    url(r'^api/proname/(?P<user_id>.*)$', UserBindPro.as_view()),
    # 用户拿到对应部门的项目
    url(r'^api/departPro/$', UserDepartPro.as_view()),
    url(r'^api/login/', LoginViewSet.as_view()),
    url(r'^api/cgepsw/', CgePsw.as_view()),
    url(r'^api/user/ordinaryuser', OrdinaryUser.as_view()),
    url(r'^api/auser/user_operation/', UserOperation.as_view()),

    url(r'^api/user/queryemail', QueryEmail.as_view()),

    url(r'^api/projects/$', ProjectInfo.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/projects/(?P<pk>.*)$', ProjectInfo.as_view({'get': 'retrieve', 'put': 'update',
                                                           'patch': 'partial_update', 'delete': 'destroy'})),

    url(r'^api/userpro/$', UserPro.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/userpro/(?P<pk>.*)$', UserPro.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update',
                                                      'delete': 'destroy'})),


    # 服务线类

    url(r'^api/group_case/$', GroupCaseInfo.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/group_case/(?P<pk>.*)$', GroupCaseInfo.as_view({'get': 'retrieve', 'put': 'update',
                                                               'patch': 'partial_update', 'delete': 'destroy'})),
    url(r'^api/project/group_case/(?P<project_id>.*)$', GroupApi.as_view()),


    url(r'^api/appinfo/$', ApplineInfo.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/appinfo/(?P<pk>.*)$', ApplineInfo.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update',
                                                          'delete': 'destroy'})),

    url(r'^api/apiInfo/$', ApiInfo.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/apiInfo/(?P<pk>.*)$', ApiInfo.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update',
                                                      'delete': 'destroy'})),
    url(r'^api/group/apiInfo/(?P<group_id>.*)$', ApiGroup.as_view()),
    url(r'api/group/run/$', RunApi.as_view()),
    url(r'api/groups/run/$', GroupRequest.as_view()),
    url(r'api/groups/creatreport', GroupReport.as_view()),
    url(r'api/project/run/$', ProjectRequest.as_view()),
    url(r'api/project/pro_report/$', ProjectInform.as_view({'get': 'list', 'post': 'create'})),
    url(r'api/project/pro_report/(?P<pk>.*)$', ProjectInform.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'})),
    url(r'api/project/recordlist/', RecordList.as_view()),

    url(r'^api/businessline/$', BusinessLine.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/businessline/(?P<pk>.*)$', BusinessLine.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'})),

    # 环境线
    url(r'^api/appEnvi/$', AppEnvi.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/appEnvi/(?P<pk>.*)$', AppEnvi.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'})),

    url(r'^api/apps/(?P<app_id>.*)$', Apps.as_view()),


    # 公共参数表
    url(r'^api/commpara/$', CommPara.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/commpara/(?P<pk>.*)$', CommPara.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'})),

    url(r'^api/records/$', RecordsView.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/records/(?P<pk>.*)$', RecordsView.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'})),
    url(r'^api/results/$', AddRecord.as_view()),
    url(r'^api/results/(?P<api_id>.*)$', AddRecord.as_view()),

    # 配置表
    url(r'^api/hosts/$', GetHosts.as_view({'get': 'list', 'post': 'create'})),
    url(r"^api/gethosts/$", get_hosts),
    url(r'^api/hosts/(?P<pk>.*)$', GetHosts.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', })),
    # 配置公共的常量变量
    url(r'^api/variable/$', VariableConfig.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/variable/(?P<project_id>.*)$', VariableConfig.as_view({'get': 'retrieve'})),

    # 配置公共的接口变量
    url(r'^api/apiparams/$', ApiParamsConfig.as_view({'get': 'retrieve', 'post': 'create'})),
    url(r'^api/apiparams/(?P<project_id>.*)$', ApiParamsConfig.as_view({'get': 'retrieve'})),
    url(r'^api/apiconfig/(?P<pk>.*)$', DeleteConfig.as_view({'delete': 'destroy'})),

    # 统计报表
    url(r'^api/apitime/$', ApiTime.as_view()),
    url(r'^api/resultcount/$', ResultsCount.as_view()),
    url(r'^api/casetotal/$', CaseTotal.as_view()),
    url(r'^api/sendEmail/$', SendEmail.as_view()),

    # 邮件配置
    url(r'^api/setEmail/$', EmailInfo.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/setEmail/(?P<pk>.*)$', EmailInfo.as_view({'get': 'retrieve'})),

    # jenkins服务配置
    url(r'^api/jenkinsList/$', JenkinsListQuery.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/runJenkins/$', RunJenkinsServe.as_view()),
    url(r'^api/jenkinsProject/$', JenkinsProject.as_view({'get': 'list', 'post': 'create'})),

    # 部门列表
    url(r'^api/department/$', DepartView.as_view({'get': 'list', 'post': 'create'})),
    url(r'^api/department/(?P<pk>.*)$', DepartView.as_view({'get': 'retrieve'})),
    url(r'^api/proDepart/$', ProDepartView.as_view()),

    # 测试工具类
    # 落地页小工具
    url(r'^api/PhoneNumber/$', PhoneQuery.as_view()),
    # 平台账号测试工具
    url(r'^api/account/check/phone/register/$', CheckPhoneRegistered.as_view()),
    url(r'^api/deluser/$', DeleteUser.as_view()),


]
