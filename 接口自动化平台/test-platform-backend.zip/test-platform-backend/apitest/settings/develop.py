import os
from .base import * #NOQA
from django.core.wsgi import get_wsgi_application
import yaml
import json

import os
# development, production

if 'env' in os.environ:
    env = os.environ['env']
else:
    env = 'development'

filename = os.path.join(os.path.dirname(__file__), 'conf/application-{}.yaml'.format(env))
with open(filename, 'r') as f:
    config = yaml.safe_load(f)


DEBUG = False
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        **config['DATABASE']
    }
}

