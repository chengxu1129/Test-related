from django.apps import AppConfig


class ServicelineConfig(AppConfig):
    name = 'serviceline'
