from rest_framework import serializers
from serviceline.models import (tbl_group_case, tbl_app, tbl_api_info,
                                tbl_api_line, tbl_api_record, tbl_project_inform)
from userauth.models import tbl_project_category
from django.db import connection
import datetime


# 组合用例序列化
class GroupcaseSerializers(serializers.ModelSerializer):
    class Meta:
        model = tbl_group_case
        fields = ('id', 'groupname', 'status_case', 'project_id', 'environment')
        extra_kwargs = {
            'groupname': {
                'required': True,
                'min_length': 4,
                'max_length': 12,
                'error_messages': {
                    'required': '字段必填',
                    'min_length': '字段太短',
                    'max_length': '字段太长',
                }
            },
            'status_case': {
                'read_only': True,
            },
            'id': {
                'read_only': True,
            },
        }

    def validate(self, attrs):
        if tbl_group_case.objects.filter(groupname=attrs['groupname'],
                                         project_id=attrs['project_id'],is_deleted=False).first():
            raise serializers.ValidationError('业务名已存在')
        return attrs


# tbl_app序列化
class AppuseSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_app
        fields = ('id', 'app_name', 'project_id')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }

    def validate_app_name(self, value):
        if tbl_app.objects.filter(app_name=value).first():
            raise serializers.ValidationError('应用名已存在')
        return value


# tbl_api_info序列化
class ApiInfoSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_api_info
        fields = ('id', 'case_name', 're_head', 're_path', 'st_host', 're_body', 'asserts', 'st_code',
                  'group_id', 'create_time', 'methods', 'need_value', 'state')
        extra_kwargs = {
            'id': {
                'read_only': True,
            },
        }


# 跑接口逻辑的
class RunapiSerializers(serializers.ModelSerializer):
    class Meta:
        model = tbl_api_info
        fields = ('id', 'case_name', 're_head', 're_path', 're_body', 'asserts', 'st_code',
                  'group_id', 'create_time', 'methods')

        extra_kwargs = {
            'case_name': {
                'read_only': True,
            },
            're_head': {
                'read_only': True,
            },
            're_path': {
                'read_only': True,
            },
            're_body': {
                'read_only': True,
            },
            'st_code': {
                'read_only': True,
            },
            'group_id': {
                'read_only': True,
            },
            'asserts': {
                'read_only': True,
            },
            'methods': {
                'read_only': True,
            },

        }


# tbl_tbl_api_line序列化
class ApiLineSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_api_line
        fields = ('id','in_apiId','out_apiId','steam_aseert','start_api')
        extra_kwargs = {
            'id':{
                'read_only': True,
            },
        }

    # def validate(self, attrs):


# 记录明细表的tbl_api_record
class ApiRecordSerializers(serializers.ModelSerializer):

    class Meta:
        model = tbl_api_record
        fields = ('id', 'start_time', 'end_time', 'api_id', 'group_id', 'apiresult')
        extra_kwargs = {
            'id':{
                'read_only' : True
            }
        }


# 测试报告
class ProjectInforms(serializers.ModelSerializer):

    class Meta:
        model = tbl_project_inform
        fields = ('id', 'start_time', 'end_time', 'project_id', 'group_ids',
                  'fullname', 'apiresult', 'pro_name', 'environment')
        extra_kwargs = {
            'id': {
                'read_only': True
            },

        }


    pro_name = serializers.SerializerMethodField()
    def get_pro_name(self,obj):

        project_ids = tbl_project_inform.objects.filter(pk__exact=obj.id).values('project_id').all()
        project = tbl_project_category.objects.filter(id__in = project_ids).all()

        for item in project:
            ret = item.pro_name
        return ret


class ProjectList(serializers.ModelSerializer):
    class Meta:
        model = tbl_project_inform
        fields = ('id', 'start_time', 'end_time', 'project_id','pro_name', 'fullname', 'environment')
        extra_kwargs = {
            'id': {
                'read_only': True
            },

        }

    def get_pro_name(self, obj):
        project_ids = tbl_project_inform.objects.filter(pk__exact=obj.id).values('project_id').all()
        project = tbl_project_category.objects.filter(id__in=project_ids).all()
        ret = []
        for item in project:
            ret = item.pro_name
        return ret

    pro_name = serializers.SerializerMethodField()


class needTime():
    def get_cur_data(self):
        return datetime.datetime.now().date()

    def get_cur_dates(self):
        return str(datetime.datetime.now())

    def get_week(self):
        return self.get_cur_data().isoweekday()
    # 拿到本周1
    def get_week_data(self):

        return str((self.get_cur_data() - datetime.timedelta(days=self.get_week() - 1))) + ' 00:00:00'
    # 拿到上周1
    def get_last_week(self):
        return str((self.get_cur_data() - datetime.timedelta(days=self.get_week() + 6))) +' 00:00:00'


# 统计本周数据
class WeekApiSerializers(serializers.ModelSerializer, needTime):
    class Meta:
        model = tbl_project_category
        fields = ('id', 'pro_name', 'case_total', 'run_total', 'last_weeks', 'all_total')

    case_total = serializers.SerializerMethodField()
    run_total = serializers.SerializerMethodField()
    last_weeks = serializers.SerializerMethodField()
    all_total = serializers.SerializerMethodField()
    def get_case_total(self, obj):

        environment = self.context['request']
        groupids = tbl_group_case.objects.filter(project_id__exact=obj.id, is_deleted=False,
                                                 environment=environment).values('id').all()
        api_total = tbl_api_info.objects.filter(group_id__in=groupids, is_deleted=False,
                                                create_time__gte=self.get_week_data(),
                                                create_time__lt=self.get_cur_dates()).all()
        return len(api_total)

    def get_run_total(self, obj):
        environment = self.context['request']
        project_ids =tbl_project_inform.objects.filter(is_deleted=False, project_id=obj.id,
                                                       environment=environment).values('project_id').all()

        res_total = tbl_project_inform.objects.filter(is_deleted=False, project_id__in=project_ids,
                                                      start_time__gte=self.get_week_data(),
                                                      start_time__lt=self.get_cur_dates()).all()
        return len(res_total)
    def get_last_weeks(self, obj):
        environment = self.context['request']
        project_ids = tbl_project_inform.objects.filter(is_deleted=False, project_id=obj.id).values('project_id').all()
        res_total = tbl_project_inform.objects.filter(is_deleted=False, project_id__in=project_ids,
                                                      start_time__gte=self.get_last_week(),
                                                      environment=environment,
                                                      start_time__lt=self.get_week_data()).all()
        return len(res_total)
    def get_all_total(self, obj):
        environment = self.context['request']
        groupids = tbl_group_case.objects.filter(project_id__exact=obj.id, is_deleted=False,
                                                 environment=environment).values('id').all()
        api_total = tbl_api_info.objects.filter(group_id__in=groupids, is_deleted=False).all()
        return len(api_total)


