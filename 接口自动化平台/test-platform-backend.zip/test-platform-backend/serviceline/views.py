import jsonpath
from django.shortcuts import render

global false, null, true
false = null = true = ''



# Create your views here.
from rest_framework.views import APIView
import json,time
from utils.jsoncode import DateEncoder

from userauth.models import tbl_token, tbl_user
from request.apirequest import RequestInfo
from request.aseertapi import RequestInfo as ParamsConfig
from config.models import tbl_apiprams_config, tbl_variable_config
from utils.response import APIRespones
from serviceline.serializers import (GroupcaseSerializers, AppuseSerializers, ApiRecordSerializers,
                                     ApiInfoSerializers, ApiLineSerializers, ProjectInforms, ProjectList,
                                     WeekApiSerializers, needTime)
from serviceline.models import (tbl_group_case, tbl_app, tbl_api_info, tbl_api_line,
                                tbl_api_record, tbl_project_inform, tbl_project_category)
from utils.methodrequest import MethodRequest
import copy

#转换时间戳格式
def timeChange(timestamp):
    timeArray = time.localtime(timestamp)
    otherStyleTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
    return otherStyleTime

# 获取真实姓名
def fullnames(auth):
    user_id = tbl_token.objects.filter(token__exact=auth).values('userId_id').all()
    fullname = tbl_user.objects.filter(id__in=user_id).values('fullname').all()
    for item in fullname:
        ret = item['fullname']
        return ret
# 获取用户的当前环境
def get_cur_envir(token):
    if token:
        try:
            userid = tbl_token.objects.filter(token__exact=token).values('userId_id').first()["userId_id"]
            envir = tbl_user.objects.filter(is_deleted=False, id=userid).values('cur_envir').first()["cur_envir"]
        except:
            envir = ''
        if envir is None or envir == '':
            envir = "test"
    else:
        envir = "test"
    return envir


# 公共变量
def CommonParams(pro_id, environment):
    ids = tbl_apiprams_config.objects.filter(is_deleted=False, project_id=pro_id,
                                             environment=environment).values('api_id').all()
    id_obje = tbl_api_info.objects.values().filter(pk__in=ids)
    param_config = eval(json.dumps(list(id_obje), cls=DateEncoder, ensure_ascii=False))

    values = ParamsConfig().requstelist(param_config)
    if isinstance(values, dict):
        pros = tbl_variable_config.objects.filter(is_deleted=False, project_id=pro_id, environment=environment).values('key', 'value').all()
        pros = eval(json.dumps(list(pros), cls=DateEncoder, ensure_ascii=False))
        for i in pros:
            if i != '':
                b = [v for k, v in i.items()]
                values[b[0]] = b[1]
        return values
    else:
        return values

#组合用例增删改查
class GroupCaseInfo(MethodRequest):

    # authentication_classes = []
    # 需要根据环境获取
    queryset = tbl_group_case.objects.filter(is_deleted=False)
    serializer_class = GroupcaseSerializers

    def create(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        request.data["environment"] = envir
        response = super().create(request, *args, **kwargs)
        return APIRespones('1000', 'ok', True, response.data)

    def partial_update(self, request, *args, **kwargs):
        id = kwargs.get('pk')
        obj = tbl_group_case.objects.filter(pk=id, is_deleted=False)
        obj.update(**request.data)

        return APIRespones(1000, 'ok', True)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 查询项目下的组合用例
class GroupApi(APIView):
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        obj = kwargs.get('project_id')
        # 增加环境下的筛选
        if obj == '':
            objs = tbl_group_case.objects.filter(is_deleted=False, environment=envir)
        else:
            objs = tbl_group_case.objects.filter(is_deleted=False, environment=envir, project_id=obj)
        obj_seri = GroupcaseSerializers(objs, many=True)
        return APIRespones(1000, '请求正常', results=obj_seri.data)


# 应用的增删改查
class ApplineInfo(MethodRequest):
    queryset = tbl_app.objects.filter(is_deleted=False, )
    serializer_class = AppuseSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 接口信息的增删改查
class ApiInfo(MethodRequest):
    authentication_classes = []
    queryset = tbl_api_info.objects.filter(is_deleted=False)
    serializer_class = ApiInfoSerializers

    def create(self, request, *args, **kwargs):
        tbl_api_info.objects.create(**request.data)
        return APIRespones(1000, 'ok', True)

    def partial_update(self, request, *args, **kwargs):
        id = kwargs.get('pk')
        obj = tbl_api_info.objects.filter(pk=id, is_deleted=False)
        obj.update(**request.data)

        return APIRespones(1000, 'ok', True)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 运行api请求
class RunApi(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        pro_id = request.data.get('project_id')
        api_id = request.data.get('id')
        values = CommonParams(pro_id, envir)
        if isinstance(values, dict):
            obj = tbl_api_info.objects.values().filter(pk=api_id, is_deleted=False)
            jsons = eval(json.dumps(list(obj), cls=DateEncoder, ensure_ascii=False))
            responses = RequestInfo().run_testcase(jsons, values, envir=envir)
            if isinstance(responses, list):
                tbl_api_info.objects.filter(pk=api_id).update(state=responses[0]['msg'])
                return APIRespones(1000, '运行完成', results=responses)
            else:
                return APIRespones(1002, 'header、body、提取值、断言值不符合json格式编写', False)
        return APIRespones(1002, '公共接口{}header、body、提取值、断言值不符合json格式编写'.format(values), False)



# 组合用例下的所有接口

class ApiGroup(APIView):

    def get(self, request, *args, **kwargs):
        obj = kwargs.get('group_id')
        objs = tbl_api_info.objects.filter(is_deleted=False, group_id=obj)
        obj_seri = ApiInfoSerializers(objs, many=True)
        return APIRespones(1000, '成功', results=obj_seri.data)


# 业务线连接请求
class BusinessLine(MethodRequest):
    queryset = tbl_api_line.objects.filter(is_deleted=False)
    serializer_class = ApiLineSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 记录明细表
class RecordsView(MethodRequest):
    queryset = tbl_api_record.objects.filter()
    serializer_class = ApiRecordSerializers

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 生成记录
class AddRecord(APIView):

    def post(self, request, *args, **kwargs):
        api_id = request.data.get('api_id')
        apiresult = request.data.get('apiresult')
        bs = ApiRecordSerializers(data=request.data)
        bs.is_valid()
        obj = tbl_api_record.objects.filter(api_id=api_id)
        if len(obj) != 0:
            tbl_api_record.objects.filter(api_id=api_id).update(apiresult=apiresult)

            return APIRespones(1000, '更新成功', results=bs.data)
        else:
            bs_obj = bs.save()
            return APIRespones(1000, '创建成功', results=ApiRecordSerializers(bs_obj).data)

    def get(self, request, *args, **kwargs):
        api_id = kwargs.get('api_id')
        obj = tbl_api_record.objects.filter(api_id=api_id)[0]
        bs = ApiRecordSerializers(obj)
        bs.data['apiresult'] = eval(bs.data['apiresult'])

        return APIRespones(1000, 'ok', results=bs.data['apiresult'])


# 运行业务流所有接口
class GroupRequest(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = get_cur_envir(token)
        group_id = request.data.get('group_id')
        pro_id = request.data.get('project_id')
        values = CommonParams(pro_id, envir)
        if isinstance(values, dict):
            obj = tbl_api_info.objects.values().filter(group_id=group_id, is_deleted=False)
            jsons = eval(json.dumps(list(obj), cls=DateEncoder, ensure_ascii=False))
            responses = RequestInfo().run_testcase(jsons, values, envir=envir)
            if isinstance(responses, list):
                return APIRespones(1000, 'ok', results=responses)
            else:
                return APIRespones(1002, '{}：header、body、提取值、断言值不符合json格式编写'.format(responses), False)
        return APIRespones(1003, '公共接口{}：header、body、提取值、断言值不符合json格式编写'.format(values), False)


# 生成组合用例的记录
class GroupReport(APIView):

    def post(self, request, *args, **kwargs):
        results = request.data.get('results')
        group_id = request.data.get('group_id')
        results = eval(results)
        msg = [item['msg'] for item in results]
        if 0 in msg:
            tbl_group_case.objects.filter(pk=group_id).update(status_case=1)
        else:
            tbl_group_case.objects.filter(pk=group_id).update(status_case=0)
        for i in results:
            lis = []
            id = i['re_info']['id']
            tbl_api_info.objects.filter(pk=id).update(state=i['msg'])
            lis.append(i)
            if len(tbl_api_record.objects.filter(api_id=id)) != 0:
                tbl_api_record.objects.filter(api_id=id).update(apiresult=str(lis))
            else:
                tbl_api_record.objects.create(api_id=id, apiresult=str(lis), group_id=group_id)

        return APIRespones(1000, 'ok', )


# 运行项目
class ProjectRequest(APIView):

    def post(self, request, *args, **kwargs):
        auth = request.META.get('HTTP_AUTHORIZATION', None)
        envir = get_cur_envir(auth)
        group_ids = request.data.get('group_ids')
        pro_id = request.data.get('project_id')
        lis = []
        for i in eval(group_ids):
            obj = tbl_api_info.objects.values().filter(group_id=i, is_deleted=False)
            jsons = eval(json.dumps(list(obj), cls=DateEncoder, ensure_ascii=False))
            lis.append(jsons)
        values = CommonParams(pro_id, envir)
        start_time = round(time.time())
        if isinstance(values, dict):
            envir = get_cur_envir(auth)
            responses = RequestInfo().requstePro(lis, values, envir=envir)
            if isinstance(responses, list):
                end_time = round(time.time())
                fullname = fullnames(auth)
                dicts = {}
                for group_id, result in zip(eval(group_ids), responses):
                    case_name = tbl_group_case.objects.values().filter(pk=group_id, is_deleted=False)
                    group_name = case_name[0]['groupname']
                    dicts[group_name] = result

                return APIRespones(1000, 'ok', results={'start_time': timeChange(start_time),
                                                        'end_time': timeChange(end_time),
                                                        'fullname': fullname,
                                                        'response': dicts,
                                                        'environment': envir})

            return APIRespones(1001, '格式不正确：{}'.format(responses), False)
        return APIRespones(1001, '公共参数不正确：{}'.format(values), False)


# 项目测试报告
class ProjectInform(MethodRequest):
    authentication_classes = []
    queryset = tbl_project_inform.objects.order_by("-id").filter(is_deleted=False)
    serializer_class = ProjectInforms

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 报告记录
class RecordList(APIView):
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        obj = tbl_project_inform.objects.order_by('-id').filter(is_deleted=False).all()
        objs = ProjectList(obj, many=True)
        return APIRespones(1000, 'OK', results=objs.data)


# 本周新增用例数
class ApiTime(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        depart_id = request.data.get('depart_id')
        environment = request.data.get('environment')
        if depart_id:
            obj = tbl_project_category.objects.filter(is_deleted=False, depart_id=depart_id)
        else:
            obj = tbl_project_category.objects.filter(is_deleted=False)

        objs = WeekApiSerializers(obj, many=True, context={'request': environment})
        return APIRespones(1000, 'OK', results=objs.data)


# 项目结果
class ResultsCount(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        ids = request.data.get('project_id')
        environment = request.data.get('environment')
        obj = tbl_project_inform.objects.order_by('-id').values().filter(is_deleted=False, project_id=ids,
                                                                         environment=environment).first()
        try:
            obj = eval(obj['apiresult'])
        except:
            return APIRespones(1000, 'ok', results={'s_count': 0, 'f_count': 0, 'project_id': ids})
        s_count = 0
        f_count = 0
        for k, v in (obj['response']).items():
            for i in v:
                if i['msg'] > 0:
                    s_count += 1
                elif i['msg'] == 0:
                    f_count += 1
        return APIRespones(1000, 'ok', results={'s_count': s_count, 'f_count': f_count,
                                                'project_id': ids})


# 本周用例总数
class CaseTotal(APIView):

    authentication_classes = []

    def post(self, request, *args, **kwargs):
        depart_id = request.data.get('depart_id')

        environment = request.data.get('environment')
        if depart_id:
            pro_id = tbl_project_category.objects.filter(depart_id=depart_id, is_deleted=False).values('id').all()
        else:
            pro_id = tbl_project_category.objects.filter(is_deleted=False).values('id').all()

        groupids = tbl_group_case.objects.filter(project_id__in=pro_id, is_deleted=False,
                                                 environment=environment).values('id').all()
        api_total = tbl_api_info.objects.values().filter(group_id__in=groupids, is_deleted=False)
        weektotal = tbl_api_info.objects.values().filter(group_id__in=groupids, is_deleted=False,
                                                         create_time__gte=needTime().get_week_data(),
                                                         create_time__lt=needTime().get_cur_dates()
                                                         )
        return APIRespones(1000, 'ok', results={'caseTotal': len(api_total), 'weekTotal': len(weektotal)})
