from django.core.validators import int_list_validator
from django.db import models

# Create your models here.

from userauth.models import tbl_user,tbl_project_category


# 业务组合用例表
class tbl_group_case(models.Model):
    STATUS_NORMAL = 0
    STATUS_FLIA = 1
    STATUS_RUN = 2
    STATUS_DEFAULT = 3
    STATUS_ITEMS = (
        (STATUS_NORMAL, '通过'),
        (STATUS_FLIA, '失败'),
        (STATUS_RUN, '运行中'),
        (STATUS_DEFAULT, '未运行'),
    )
    environment = models.CharField(max_length=20, verbose_name='运行环境', default='test')
    groupname = models.CharField(max_length=20, verbose_name='业务流程名')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    status_case = models.PositiveIntegerField(default=STATUS_DEFAULT,
                                              choices=STATUS_ITEMS,
                                              verbose_name='业务状态')
    project_id = models.IntegerField()
    is_deleted = models.BooleanField(default=False, null=False)

    class Meta:
        db_table = 'tbl_group_case'


# 应用表
class tbl_app(models.Model):
    app_name = models.CharField(max_length=20, verbose_name='应用名称')
    is_deleted = models.BooleanField(default=False, null=False)
    project_id = models.IntegerField()

    class Meta:
        db_table = 'tbl_app'


# 接口信息表
class tbl_api_info(models.Model):
    case_name = models.CharField(max_length=20, verbose_name='接口名称')
    re_head = models.TextField(verbose_name='请求头')
    re_path = models.TextField(verbose_name='请求路径')
    re_body = models.TextField(verbose_name='请求体', default='')
    st_host = models.CharField(max_length=200, verbose_name='请求域名')
    asserts = models.CharField(max_length=50, verbose_name='断言', default='')
    st_code = models.CharField(verbose_name='状态码', max_length=255)
    group_id = models.IntegerField()
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    app_id = models.IntegerField(default=0)
    methods = models.CharField(max_length=20, verbose_name='请求方式')
    state = models.CharField(max_length=20, verbose_name='结果', default='')
    need_value = models.CharField(max_length=100, verbose_name='提取参数', default='')
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_api_info'


# 接口业务线表
class tbl_api_line(models.Model):
    STATUS_NORMAL = 0
    STATUS_START = 1
    STATUS_ITEMS = (
        (STATUS_NORMAL, '普通'),
        (STATUS_START, '开始接口')
    )

    in_apiId = models.IntegerField()
    out_apiId = models.IntegerField()
    steam_aseert = models.CharField(max_length=100, verbose_name='业务流分支断言')
    start_api = models.PositiveIntegerField(default=STATUS_NORMAL,
                                            choices=STATUS_ITEMS,
                                            verbose_name='业务状态')
    is_deleted = models.BooleanField(default=False, null=False)

    class Meta:
        db_table = 'tbl_api_line'


# 记录明细表
class tbl_api_record(models.Model):
    start_time = models.DateTimeField(auto_now=True, verbose_name='开始时间')
    end_time = models.DateTimeField(auto_now=True, verbose_name='结束时间')
    api_id = models.IntegerField(verbose_name='接口ID')
    apiresult = models.TextField(verbose_name='请求结果', default='')
    group_id = models.IntegerField()

    class Meta:
        db_table = 'tbl_api_record'


# 测试报告
class tbl_project_inform(models.Model):
    start_time = models.CharField(max_length=30, verbose_name='开始时间')
    end_time = models.CharField(max_length=30, verbose_name='结束时间')
    project_id = models.IntegerField(verbose_name='项目ID')
    group_ids = models.TextField(validators=[int_list_validator], default=[])
    apiresult = models.TextField(verbose_name='请求结果', default='')
    is_deleted = models.BooleanField(default=False)
    fullname = models.CharField(max_length=25, verbose_name='操作人', default='')
    environment = models.CharField(max_length=25, verbose_name='环境', default='test')

    class Meta:
        db_table = 'tbl_project_inform'
