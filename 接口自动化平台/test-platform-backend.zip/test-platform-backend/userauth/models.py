from django.db import models
from django.core.validators import int_list_validator

# Create your models here.


# 用户表
class tbl_user(models.Model):
    AUTH_ADMIN = 1
    AUTH_USER = 0
    AUTH_GROUP = (
        (AUTH_ADMIN, '管理员'),
        (AUTH_USER, '普通用户'),
    )
    username = models.CharField(max_length=30, verbose_name='用户名')
    password = models.CharField(max_length=30, verbose_name='密码')
    email = models.EmailField(verbose_name='邮箱', default='')
    fullname = models.CharField(max_length=16, verbose_name="真实姓名")
    auth = models.PositiveIntegerField(default=AUTH_USER,
                                       choices=AUTH_GROUP,
                                       verbose_name='权限')
    cur_envir = models.CharField(max_length=30, verbose_name="当前环境", default='test')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    is_deleted = models.BooleanField(default=False)
    res_pwd = models.CharField(max_length=12, verbose_name="确认密码", null=True)

    class Meta:
        db_table = 'tbl_user'


# token表
class tbl_token(models.Model):
    token = models.CharField(max_length=255)
    userId = models.OneToOneField(to='tbl_user', on_delete=models.CASCADE)
    class Meta:
        db_table = 'tbl_token'


# 项目类别表
class tbl_project_category(models.Model):
    depart_id = models.IntegerField(verbose_name='部门id', default=0)
    pro_name = models.CharField(max_length=50, verbose_name='项目名')
    # environment = models.CharField(max_length=50, verbose_name='环境')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now_add=True, verbose_name='更新时间')
    send_email = models.TextField(validators=[int_list_validator], default=[], verbose_name='关联用户ID')
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_project_category'


# 用户项目表
class tbl_user_project(models.Model):
    userId = models.IntegerField()
    project_id = models.IntegerField()
    add_time = models.DateTimeField(auto_now_add=True, verbose_name='入项时间')
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_user_project'


# 部门列表
class tbl_department(models.Model):
    depart_name = models.CharField(max_length=50, verbose_name="部门名称")
    add_time = models.DateField(auto_now=True, verbose_name="新增时间")
    is_deleted = models.BooleanField(default=False)

    class Meta:
        db_table = 'tbl_department'
