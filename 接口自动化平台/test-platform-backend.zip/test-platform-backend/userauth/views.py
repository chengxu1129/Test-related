from django.shortcuts import render

# Create your views here.
# from rest_framework.viewsets import GenericViewSet,ModelViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from utils.methodrequest import MethodRequest
from utils.response import APIRespones
from userauth.models import tbl_user, tbl_project_category, tbl_token, tbl_user_project, tbl_department
from userauth.serializers import (UserIonfoSerializer, UserLoginSerializer,
                                  UserPswSerializer, UserPjcSerializer,
                                  ProauthSerializer, UserProjects, UserInfoSerializer,
                                  DepartmentSerializer)


def md5(user):
    import hashlib
    import time

    ctime = str(time.time())

    m = hashlib.md5(bytes(user,encoding='utf-8'))
    m.update(bytes(ctime,encoding='utf-8'))
    return m.hexdigest()


# 登陆
class LoginViewSet(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        user = request.data.get("username")
        pwd = request.data.get("password")
        objs = tbl_user.objects.filter(username=user, password=pwd).first()
        obj = UserLoginSerializer(data=request.data)
        if obj.is_valid(raise_exception=False):
            bs = objs
            token = md5(user)
            tbl_token.objects.update_or_create(userId=objs, defaults={'token': token})
            bsc = UserLoginSerializer(bs).data
            bsc['token'] = token
            return APIRespones(1000, '登录成功', results=bsc)
        else:
            return APIRespones(1001, '账号密码错误', False)


# 注册
class Register(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        bs = UserIonfoSerializer(data=request.data)
        if bs.is_valid(raise_exception=True):
            bs_obj = bs.save()
            return Response({
                'status': 1000,
                'msg': '注册成功',
                'succese': True,
                'result': UserIonfoSerializer(bs_obj).data
            })
        else:
            return APIRespones(1001, '账号已存在', False)

    def get(self, request, *args, **kwargs):
        obj = kwargs.get('pk')
        objs = tbl_user.objects.filter(pk=obj, is_deleted=False)
        obj_pk = UserIonfoSerializer(objs, many=True)
        return APIRespones(1000, '成功', results=obj_pk.data)


# 修改密码
class CgePsw(APIView):
    authentication_classes = []

    def patch(self, request, *args, **kwargs):
        user = request.data.get('username')
        old_user = tbl_user.objects.filter(username=user).first()
        chagewd = UserPswSerializer(instance=old_user, data=request.data, partial=True)
        chagewd.is_valid(raise_exception=True)
        chagewd.save()
        return APIRespones(1000, '修改成功', results=chagewd.data)


# 普通用户
class OrdinaryUser(APIView):
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        obj = tbl_user.objects.filter(auth=0, is_deleted=False)
        obj_pk = UserInfoSerializer(obj, many=True)
        return APIRespones(1000, '成功', results=obj_pk.data)


# 用户的改动
class UserOperation(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        userid = request.data.get("userid")
        token = request.META.get("HTTP_AUTHORIZATION")
        envir = request.data.get("cur_envir")
        cur_token = tbl_token.objects.filter(userId_id=userid).values('token').first()
        if token == cur_token.get("token"):
            tbl_user.objects.filter(id=userid).update(cur_envir=envir)
            return APIRespones(1000, '环境切换成功')
        else:
            return APIRespones(1001, '不能修改别人的环境')


# 查询邮箱
class QueryEmail(APIView):
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        obj = tbl_user.objects.filter(is_deleted=False)
        obj_pk = UserInfoSerializer(obj, many=True)
        return APIRespones(1000, '成功', results=obj_pk.data)


# 项目增删改查
class ProjectInfo(MethodRequest):

    authentication_classes = []
    queryset = tbl_project_category.objects.filter(is_deleted=False)
    serializer_class = UserPjcSerializer

    def retrieve(self, request, *args, **kwargs):
        depart_id = kwargs.get('pk')
        obj = tbl_project_category.objects.filter(is_deleted=False, depart_id=depart_id)

        objs = UserPjcSerializer(obj, many=True)
        return APIRespones(1000, '成功', results=objs.data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 增加对应项目人员
class UserPro(MethodRequest):
    authentication_classes = []
    queryset = tbl_user_project.objects.filter(is_deleted=False)
    serializer_class = ProauthSerializer

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if not instance:
            return APIRespones(1001, '删除失败', False)
        instance.is_deleted = True
        instance.save()
        return APIRespones(1000, '删除成功')


# 用户项目对应关系
class UserBindPro(APIView):
    authentication_classes = []

    def get(self, request, *args, **kwargs):
        obj = kwargs.get('user_id')

        objs = tbl_user_project.objects.filter(userId=obj)

        obj_id = UserProjects(objs, many=True)

        return APIRespones(1000, '成功', results=obj_id.data[0])


# 用户对应部门项目
class UserDepartPro(APIView):

    authentication_classes = []

    def post(self, request, *args, **kwargs):
        obj = request.data
        objs = tbl_user_project.objects.filter(userId__exact=obj.get('userId')).values_list('project_id').all()
        project = tbl_project_category.objects.filter(id__in=objs, depart_id=obj.get('depart_id')).all()
        ret = []
        for item in project:
            ret.append({'project_id': item.id, 'pro_name': item.pro_name})

        return APIRespones(1000, '成功', results=ret)


# 部门列表
class DepartView(MethodRequest):
    authentication_classes = []
    queryset = tbl_department.objects.filter(is_deleted=False)
    serializer_class = DepartmentSerializer


# 筛选个人对应的部门
class ProDepartView(APIView):
    authentication_classes = []

    def post(self, request, *args, **kwargs):
        obj = request.data.get('userId')
        project_ids = tbl_user_project.objects.filter(userId__exact=obj).values_list('project_id').distinct().all()
        depart_id = tbl_project_category.objects.filter(id__in=project_ids,
                                                        is_deleted=False).values_list('depart_id').distinct().all()
        departments = tbl_department.objects.filter(id__in=depart_id).all()
        res = []
        for item in departments:
            res.append({"depart_id": item.id, "depart_name": item.depart_name})
        return APIRespones(1000, '成功', results=res)
