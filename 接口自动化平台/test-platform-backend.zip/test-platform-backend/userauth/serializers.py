from rest_framework import serializers
from userauth.models import tbl_user, tbl_project_category, tbl_user_project, tbl_department
from utils.response import APIRespones
from rest_framework.response import Response


# 用户注册
class UserIonfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = tbl_user
        fields = ('username', 'password', 'email', 'fullname', 'id', 'auth', 'create_time')
        extra_kwargs = {
            'username': {
                'required': True,
                'min_length': 6,
                'max_length': 12,
                'write_only': True,
                'error_messages': {
                    'required': '字段必填',
                    'min_length': '字段太短',
                    'max_length': '字段太长',
                }
            },
            'password': {
                'required': True,
                'min_length': 6,
                'max_length': 12,
                'write_only': True,
                'error_messages': {
                    'required': '字段必填',
                    'min_length': '字段太短',
                    'max_length': '字段太长',
                }
            },
            'fullname': {
                'required': True,
                'min_length': 2,
                'max_length': 12,
                'write_only': True,
                'error_messages': {
                    'required': '字段必填',
                    'min_length': '字段太短',
                    'max_length': '字段太长',
                }
            },
            'email': {
                'required': True,
                'write_only': True,
                'error_messages': {
                    'required': '字段必填',
                }
            },
            'id':{
                'read_only':True,
            },
            'auth': {
                'read_only': True,
            },
            'create_time': {
                'read_only': True,
            },
        }
        depth = 1

    def validate_username(self,value):

        if tbl_user.objects.filter(username=value).first():
            raise serializers.ValidationError('用户名已存在')
        return value


# 修改密码
class UserPswSerializer(serializers.ModelSerializer):

    def validate(self, attrs):
        pwd = attrs.get('password')

        res_pwd = attrs.pop('res_pwd')
        if tbl_user.objects.filter(username=attrs['username']).first():
            raise serializers.ValidationError("账号不存在")
        print(res_pwd)
        if pwd != res_pwd:
            raise serializers.ValidationError("密码不一致")
        return attrs

    class Meta:
        model = tbl_user
        fields = ('username', 'password', 'res_pwd')


# 登陆
class UserLoginSerializer(serializers.ModelSerializer):
    def validate(self, attrs):
        if not tbl_user.objects.filter(username=attrs['username'], password=attrs['password']).first():
            raise serializers.ValidationError('账号密码错误')
        return attrs

    class Meta:
        model = tbl_user
        fields = ('id', 'username', 'password', 'cur_envir')
        extra_kwargs = {
            'id': {
                'read_only': True,
            }
        }


class UserInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = tbl_user
        fields = ('id', 'username', 'email')


# 表tbl_project_category序列化
class UserPjcSerializer(serializers.ModelSerializer):

    def validate(self, attrs):

        if tbl_project_category.objects.filter(pro_name=attrs['pro_name'], is_deleted=False).first():
            raise serializers.ValidationError("项目名已存在")
        return attrs

    class Meta:
        model = tbl_project_category
        fields = ('id', 'pro_name', 'create_time', 'depart_id', 'is_deleted')

        extra_kwargs = {
            'pro_name': {
                'required': True,
                'min_length': 4,
                'max_length': 12,
                'error_messages': {
                    'required': '字段必填',
                    'min_length': '字段太短',
                    'max_length': '字段太长',
                }
            },
            'is_deleted': {
                'read_only': True,
            },
            'create_time': {
                'read_only': True,
            },
            'id':{
                'read_only': True,
            }
        }


# 增加对应人到项目权限
class ProauthSerializer(serializers.ModelSerializer):

    class Meta:
        model = tbl_user_project
        fields = '__all__'


# 修改用户
class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = tbl_user
        fields = '__all__'


# 人员对应的所有项目联表
class UserProjects(serializers.ModelSerializer):
    class Meta:
        model = tbl_user_project
        fields = ('userId', 'projct')

    projct = serializers.SerializerMethodField()

    def get_projct(self, obj):

        project_ids = tbl_user_project.objects.filter(userId__exact=obj.userId).values_list('project_id').all()
        project = tbl_project_category.objects.filter(id__in=project_ids).all()
        ret = []
        for item in project:
            ret.append({'project_id': item.id, 'pro_name': item.pro_name})
        return ret


# 部门列表
class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = tbl_department
        fields = ('id', 'depart_name', 'add_time')


# 根据人员绑定的项目查找部门
class ProjectDepartment(serializers.ModelSerializer):
    class Meta:
        model = tbl_user_project
        fields = ('userId', 'department')
    department = serializers.SerializerMethodField()

    def get_department(self, obj):
        userid = list(str(obj.userId))
        project_ids = tbl_user_project.objects.filter(userId__in=userid,
                                                      ).values_list('project_id').distinct().all()
        depart_id = tbl_project_category.objects.filter(id__in=project_ids,
                                                        is_deleted=False).values_list('depart_id').distinct().all()
        departments = tbl_department.objects.filter(id__in=depart_id).all()
        print(departments)

