# -*- coding: utf-8 -*-# 
#-------------------------------------------------------------------------------
# Name:         assert
# Description:  
# Author:       yuanbaojun
# Date:         2020/10/25
#----------------------------
import decimal
import importlib
import logging,json
import random,os
import re,datetime,time,requests
from configparser import ConfigParser
from decimal import Decimal
from faker import Faker


class AssertSrc():
    """
    环境生成域名和断言主类
    """

    def __init__(self, base_info_dict):
        self.update_binded_variables(base_info_dict)

    def update_binded_variables(self, base_info_dict):
        self.base_info_dict = base_info_dict

    def get_variables(self):
        return self.base_info_dict

    def get_functions(self,func_name):
        module = func_name.split('.')[0]
        func = func_name.split('.')[1].split('()')[0]
        if module == 'Faker':
            test_obj = Faker(locale='zh_CN')
        elif module == 'random':
            test_obj = importlib.import_module('random')
        else:
            module_a = importlib.import_module('test_platform_backend.utils.Src')
            test_obj = getattr(module_a, module)()
        ex_result = getattr(test_obj, func)()
        return ex_result


    def update_yaml_info(self,content):
        """通用的递归方法可以获取到yaml文件和json文件的变量和函数并替换为函数或者变量的值"""
        
        if content is None:
            return None
        if isinstance(content, (list, tuple)):
            # 如果入参为列表或者元祖则对每个列表元祖的值按顺序继续递归
            return [
                self.update_yaml_info(item)
                for item in content
            ]
        if isinstance(content, dict):
            # 如果是字典内容开始分离键和值，同时分别递归，然后更新键值对
            evaluated_data = {}
            for key, value in content.items():
                eval_key = self.update_yaml_info(key)
                eval_value = self.update_yaml_info(value)
                evaluated_data[eval_key] = eval_value
            return evaluated_data
        if isinstance(content, int):
            return content
        if isinstance(content, (str, bytes)):
            # 如果遇到内容为字节或者字符串开始正则（这里数据一般来自上面字典分离时获取的数据）
            content = content.strip()
            if re.findall(r"\$([\w_]+)", content):
                variable_name = re.findall(r"\$([\w_]+)", content)[0]
                try:
                    variable_value = self.get_variables()[variable_name]
                except Exception as e:
                    print(f"没有定义的变量{e}")
                    variable_value = content
                # variable_value =exec('self.USER_ID')
                if isinstance(variable_value, int):
                    # 对字典的值做的特殊处理
                    variable_value = str(variable_value)
                # 主函数变量替换代码
                content = content.replace("${}".format(variable_name), variable_value, 1)
            elif re.findall(r"\$\{([\w_]+\.[\w_]+\([\$\w\.\-_ =,]*\))\}", content):
                func_name = re.findall(r"\$\{([\w_]+\.[\w_]+\([\$\w\.\-_ =,]*\))\}", content)[0]
                func_value = self.get_functions(func_name)
                # func_value = eval(func_name)
                # print(type(func_value))
                if isinstance(func_value, (int,float,complex)):
                    func_value = str(func_value)
                if isinstance(func_value, decimal.Decimal):
                    # 特殊数据的处理
                    func_value = str(Decimal(func_value).quantize(Decimal('0.00000')))
                if isinstance(func_value, datetime.datetime):
                    # 特殊数据的处理
                    func_value = func_value.__str__()
                info = "${" + func_name + "}"
                # 主函数函数替换代码
                content = content.replace(info, func_value, 1)
            return content


