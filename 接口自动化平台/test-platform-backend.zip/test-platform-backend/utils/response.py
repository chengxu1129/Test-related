from rest_framework.response import Response


# 公用的响应
class APIRespones(Response):

    """
    Respones({
        'status':0,
        'msg':'ok',
        'results':[],
        'token':'',
    })
    """
    def __init__(self, data_status=0, data_msg='ok', res_status=True, results=None, http_status=None,
                 headers=None, exception=False, **kwargs):
        data = {
            'status': data_status,
            'msg': data_msg,
            'succese': res_status,
        }
        if results is not None:
            data['results'] = results
        data.update(kwargs)
        super().__init__(data=data, status=http_status, headers=headers, exception=exception)
