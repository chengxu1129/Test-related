# -*- coding: utf-8 -*-# 
#-------------------------------------------------------------------------------
# Name:         Src
# Description:  
# Author:       yuanbaojun
# Date:         2020/10/25
#----------------------------


# 注意这个文件主要写的是方法

class Src():
    @staticmethod
    def cur_env(env:str,key=None):
        pass
        return "函数运行结果"