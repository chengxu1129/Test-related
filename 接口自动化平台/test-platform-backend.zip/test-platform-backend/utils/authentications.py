#自定义认证类

from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from userauth.models import tbl_token
from utils.response import APIRespones

class APIAuthentication(BaseAuthentication):
    def authenticate(self, request):
        # token = request.data.get("token")
        auth = request.META.get('HTTP_AUTHORIZATION', None)
        if auth is None:
            raise AuthenticationFailed('token不存在')

        token_obj = tbl_token.objects.filter(token=auth).first()
        if not token_obj:
            raise AuthenticationFailed('用户校验不通过')

        return (token_obj.userId, token_obj)

    def authenticate_header(self, request):
        pass