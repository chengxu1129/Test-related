from rest_framework.views import APIView
from utils.response import APIRespones
from .hosts_conf import platform_it_hosts
import requests


# 平台账号小工具
# 用户账号：查询手机号是否已经注册
class CheckPhoneRegistered(APIView):

    def post(self, request, *args, **kwargs):
        params = request.data
        env_key = str(params.get('value'))
        env_dict = {"1": "dev", "2": "test", "3": "staging"}
        if str(env_key) not in env_dict.keys():
            raise Exception("env参数错误", env_key)
        human_environment = env_dict[str(env_key)]
        host = platform_it_hosts(env_key).get('platform_account_service_host')
        res = requests.get(host+"/accounts/identity/check?identity="+str(params.get('phone')))
        results = {}
        # 手机号已注册
        if res.status_code == 200:
            results = {'key': env_key,
                       'environment': human_environment,
                       'userId': res.json()['id'],
                       'email': res.json()['email'],
                       'username': res.json()['username']
                       }
        # 手机号未注册
        else:
            results = {'key': env_key,
                       'environment': human_environment,
                       'userId': None,
                       'email': None,
                       'username': None
                       }
        return APIRespones('1000', 'ok', results=results)
