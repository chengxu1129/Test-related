import redis

from testtools.redis_conf import env_choice


class Redis_link_platform:
    # 查询平台的验证码
    def __init__(self, env):
        try:
            self.r = redis.Redis(host=env_choice(env)["platform_redis"], port=env_choice(env)["platform_redis_port"],
                                 password=env_choice(env)["platform_redis_password"], decode_responses=True, db=1)
        except:
            print("link redis error")

    def get_captcha(self, phoneNum):

        try:
            captcha = self.r.hget("platform:account:captcha:login_with_register:%s" % (phoneNum), "captcha")
            return captcha
        except:
            return "link redis error"

    def get_captcha_order(self, phoneNum):
        '''获取平台订单验证码'''
        try:
            captcha = self.r.hget("platform:account:captcha:login:%s" % (phoneNum), "captcha")
            return captcha
        except:
            return "link redis error"


class Redis_link_platform_landing:
    # 查询落地页的验证码
    def __init__(self, env):
        try:
            self.r = redis.Redis(host=env_choice(env)["platform_redis"], port=env_choice(env)["platform_redis_port"],
                                 password=env_choice(env)["platform_redis_password"], decode_responses=True, db=0)
        except:
            print("link redis error")

    def get_captcha(self, phoneNum):
        try:
            captcha = self.r.get("SERVICE:LANDING:MKT:%s" % (phoneNum))
            return captcha
        except:
            return "link redis error"


class Redis_link_platform_introduce:
    # 获取转介绍的验证码--极验
    def __init__(self, env):
        try:
            self.r = redis.Redis(host=env_choice(env)["platform_redis"], port=env_choice(env)["platform_redis_port"],
                                 password=env_choice(env)["platform_redis_password"], decode_responses=True, db=1)
        except:
            print("link redis error")

    def get_captcha(self, phoneNum):
        try:
            captcha = self.r.get("tiger:account:captcha:login:%s" % (phoneNum))
            return captcha
        except:
            return "link redis error"


class Redis_link_platform_introduce_nojy:
    # 获取转介绍的验证码--非极验
    def __init__(self, env):
        try:
            self.r = redis.Redis(host=env_choice(env)["zjs_redis"], port=env_choice(env)["platform_redis_port"],
                                 password=env_choice(env)["zjs_redis_password"], decode_responses=True, db=0)
        except:
            print("link redis error.")

    def get_captcha(self, phoneNum):
        try:
            captcha = self.r.get("codemaster:market:service:%s" % (phoneNum))
            return captcha
        except:
            return "link redis error"


if __name__ == "__main__":
    print(Redis_link_platform_landing("dev").get_captcha(13197552921))