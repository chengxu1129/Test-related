def platform_it_hosts(env):

    if env == '1':
        platform_account_service_host = 'http://dev-internal.platform.codemao.cn'

    elif env == '2':
        platform_account_service_host = 'http://test-internal.platform.codemao.cn'

    elif env == '3':
        platform_account_service_host = 'http://staging-internal.platform.codemao.cn'
    return dict(platform_account_service_host=platform_account_service_host)