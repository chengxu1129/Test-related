from rest_framework.views import APIView
from utils.response import APIRespones
from utils.methodrequest import MethodRequest
from testtools.dboepration import DbOperation
from testtools.dbconf import dev_connect, test_connect, stage_connect1, stage_connect2

#B2C小工具
class DeleteUser(APIView):
    authentication_classes = []
    def post(self, request, *args, **kwargs):
        params = request.data
        print(params)
        env_key = str(params.get('enviroment'))
        user_id = str(params.get('userid'))
        print(type(env_key),type(user_id))
        env_dict = {"1": "dev", "2": "test", "3": "staging"}
        if str(env_key) not in env_dict.keys():
            raise Exception("env参数错误", env_key)
        if env_key == "1":
            a = DbOperation()
            a.crm_operation(user_id, **dev_connect)
            a.basics_operation(user_id, **dev_connect)
            a.codecamp_operation(user_id, **dev_connect)
        elif env_key == "2":
            a = DbOperation()
            a.crm_operation(user_id, **test_connect)
            a.basics_operation(user_id, **test_connect)
            a.codecamp_operation(user_id, **test_connect)
        elif env_key == "3":
            a = DbOperation()
            a.crm_operation(user_id, **stage_connect1)
            a.codecamp_operation(user_id, **stage_connect1)
            a.basics_operation(user_id, **stage_connect2)
        return APIRespones('1000', 'ok', '删除成功')
