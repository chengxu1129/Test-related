def env_choice(env):
    if env == "2":
        platform_redis = "r-bp1a97853b5914d4289.redis.rds.aliyuncs.com"
        platform_redis_port = 6379
        platform_redis_password = "1dVIrGV24PcgOELF5rNphq1L"
        zjs_redis = "r-bp1a97853b5914d4289.redis.rds.aliyuncs.com"
        zjs_redis_password = "1dVIrGV24PcgOELF5rNphq1L"

    elif env == "1":
        platform_redis = "r-bp19c78721368bd4371.redis.rds.aliyuncs.com"
        platform_redis_port = 6379
        platform_redis_password = "liuWcl8hj3InVQONzonkIeNa"
        zjs_redis = "r-bp1d854fe0104034155.redis.rds.aliyuncs.com"
        zjs_redis_password = "8zekBFunyux7i7wea99fwuUE"

    elif env == "3":
        platform_redis = "r-bp1eeeb51fc1af04.redis.rds.aliyuncs.com"
        platform_redis_port = 6379
        platform_redis_password = "5myAJrYGgJYSGiSrhgGdcsJp"
        zjs_redis = "r-bp1eeeb51fc1af04.redis.rds.aliyuncs.com"
        zjs_redis_password = "5myAJrYGgJYSGiSrhgGdcsJp"

    return dict(platform_redis=platform_redis, platform_redis_port=platform_redis_port,
                platform_redis_password=platform_redis_password, zjs_redis=zjs_redis,
                zjs_redis_password=zjs_redis_password)