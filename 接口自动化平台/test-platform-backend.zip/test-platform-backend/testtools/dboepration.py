import pymysql
from testtools.dbconf import dev_connect, test_connect, stage_connect1, stage_connect2


#数据库操作
class DbOperation():

    def crm_operation(self, user_id, **env):
        connection = pymysql.connect(host=env['host'],
                                     user=env['user'],
                                     password=env['password'],
                                     db='crm_center',
                                     port=env['port'],
                                     charset=env['charset'])
        cursor = connection.cursor()
        sql = 'update crm_customer set deleted=1 where user_id=' + user_id + ''
        cursor.execute(sql)
        connection.commit()
        connection.close()
        print('delete ok')

    def codecamp_operation(self, user_id, **env):
        connection = pymysql.connect(host=env['host'],
                                     user=env['user'],
                                     password=env['password'],
                                     db='codecamp',
                                     port=env['port'],
                                     charset=env['charset'])
        cursor = connection.cursor()
        sql1 = 'update tbl_class_assignment set is_deleted=1 where user_id=' + user_id + ''
        sql2 = 'update tbl_purchased_package set is_deleted=1 where user_id=' + user_id + ''
        cursor.execute(sql1)
        cursor.execute(sql2)
        connection.commit()
        connection.close()
        print('delete ok')


    def basics_operation(self, user_id, **env):
        connection = pymysql.connect(host=env['host'],
                                     user=env['user'],
                                     password=env['password'],
                                     db='edu_mlz_basics',
                                     port=env['port'],
                                     charset=env['charset'])
        cursor = connection.cursor()
        sql1 = 'delete from tbl_b2c_user where user_id=' + user_id + ''
        sql2 = 'delete from tbl_b2c_reservation_user where user_id=' + user_id + ''
        sql3 = 'delete from tbl_b2c_order where user_id=' + user_id + ''
        sql4 = 'delete from tbl_b2c_register_user where user_id=' + user_id + ''
        sql5 = 'delete from tbl_b2c_invalid_user where user_id=' + user_id + ''
        sql6 = 'delete from tbl_b2c_user_stage where user_id=' + user_id + ''
        cursor.execute(sql1)
        cursor.execute(sql2)
        cursor.execute(sql3)
        cursor.execute(sql4)
        cursor.execute(sql5)
        cursor.execute(sql6)
        connection.commit()
        connection.close()
        print('delete ok')

