from rest_framework.views import APIView
from utils.response import APIRespones
from testtools.get_sms import Redis_link_platform_landing as PhoneQueryNumber

# 落地页小工具
class PhoneQuery(APIView):
    def post(self, request, *args, **kwargs):
        dic = {'1':'dev', '2':'test', '3':'staging'}
        params = request.data
        captcha = PhoneQueryNumber(str(params['value'])).get_captcha(params['phone'])
        return APIRespones(1000, 'ok', results=[{'phoneNumber': params['phone'],
                                                'environment': dic[str(params['value'])],
                                                'captcha': captcha,
                                                'key': params['value']
                                                }])
