#数据库配置
dev_connect = {'host': 'rm-bp1udh67050zd1n0b115.mysql.rds.aliyuncs.com',
               'user': 'tiger_people',
               'password': 'oqp3YyGP64YjhsCplfjYnRw7ozx6foRa',
               'port': 3306,
               'charset': 'utf8'}

test_connect = {'host': 'rm-bp15t47j196je1u0l906.mysql.rds.aliyuncs.com',
                'user': 'test_all',
                'password': 'dNYnDCDfT45qUxzM9KoDrKWX',
                'port': 3306,
                'charset': 'utf8'}

#staging其他数据库
stage_connect1 = {'host': 'rm-bp1va24i42upn6l22.mysql.rds.aliyuncs.com',
                  'user': 'staging_all',
                  'password': 'tE6JnVoplLGJVD32JMB2Jgcc',
                  'port': 3306,
                  'charset': 'utf8'}

#staging edu_mlz_basics数据库
stage_connect2 = {'host': 'rm-bp1kk1l0h05922g66.mysql.rds.aliyuncs.com',
                  'user': 'stag_all',
                  'password': 'JFfj39HOGH93hH',
                  'port': 3306,
                  'charset': 'utf8'}
